using System.Collections.Generic;
using System.Linq;
using UnityEngine;

namespace BfbbImport
{
    /// <summary>
    /// Converts a parsed RwClump into a Unity scene graph: a root GameObject with one child
    /// per atomic (mesh), using SkinnedMeshRenderer when skin data is present and MeshRenderer
    /// otherwise. Frame hierarchy becomes the Transform hierarchy.
    /// </summary>
    public static class ClumpBuilder
    {
        public static GameObject Build(RwClump clump, string rootName, Dictionary<string, Texture2D> textures, Shader shader)
        {
            var root = new GameObject(rootName);

            // Create one Transform per frame, matching the frame hierarchy.
            var frameTransforms = new Transform[clump.Frames.Count];
            for (int i = 0; i < clump.Frames.Count; i++)
            {
                var f = clump.Frames[i];
                var go = new GameObject(string.IsNullOrEmpty(f.Name) ? $"Frame_{i}" : f.Name);
                frameTransforms[i] = go.transform;
            }
            for (int i = 0; i < clump.Frames.Count; i++)
            {
                var f = clump.Frames[i];
                var t = frameTransforms[i];
                t.SetParent(f.ParentIndex >= 0 ? frameTransforms[f.ParentIndex] : root.transform, false);
                ApplyLocalMatrix(t, f.LocalMatrix);
            }

            // Bone array for skinning, sized and ordered by each frame's assigned BoneIndex
            // (from the HAnim root's id->index table when available) — NOT by frame-list order,
            // which RenderWare does not guarantee matches the Skin PLG's per-vertex indices.
            int maxBoneIndex = -1;
            for (int i = 0; i < clump.Frames.Count; i++)
                if (clump.Frames[i].BoneId >= 0 && clump.Frames[i].BoneIndex > maxBoneIndex)
                    maxBoneIndex = clump.Frames[i].BoneIndex;

            Transform[] boneArray = new Transform[maxBoneIndex + 1];
            for (int i = 0; i < clump.Frames.Count; i++)
            {
                var f = clump.Frames[i];
                if (f.BoneId >= 0 && f.BoneIndex >= 0 && f.BoneIndex < boneArray.Length)
                    boneArray[f.BoneIndex] = frameTransforms[i];
            }

            // A null slot here means some bone index referenced by the skeleton (via the HAnim
            // table or fallback numbering) was never actually matched to a frame — SkinnedMeshRenderer
            // will then render NOTHING for any mesh using that bone array, with no error logged.
            // Fall back to the root bone for missing slots so the mesh at least renders (rigidly,
            // for that bone) rather than vanishing entirely, and log exactly which slots were empty.
            var missingSlots = new List<int>();
            for (int i = 0; i < boneArray.Length; i++)
            {
                if (boneArray[i] == null)
                {
                    missingSlots.Add(i);
                    boneArray[i] = boneArray.FirstOrDefault(b => b != null) ?? root.transform;
                }
            }
            if (missingSlots.Count > 0)
            {
                Debug.LogWarning($"[DffImporter] {missingSlots.Count} bone slot(s) out of {boneArray.Length} were never " +
                                  $"matched to a frame (indices: {string.Join(",", missingSlots)}). This usually means the " +
                                  "skeleton's HAnim bone table references more/different bones than the frame list actually " +
                                  "has — those slots were filled with a fallback bone so the mesh still renders, but skinning " +
                                  "will be visibly wrong for vertices weighted to the missing bone(s).");
            }

            foreach (var atomic in clump.Atomics)
            {
                if (atomic.FrameIndex < 0 || atomic.FrameIndex >= frameTransforms.Length) continue;
                if (atomic.GeometryIndex < 0 || atomic.GeometryIndex >= clump.Geometries.Count) continue;

                try
                {
                    BuildAtomic(clump, atomic, frameTransforms, boneArray, textures, shader);
                }
                catch (System.Exception ex)
                {
                    Debug.LogError($"[DffImporter] Failed to build mesh for atomic (frame {atomic.FrameIndex}, " +
                                    $"geometry {atomic.GeometryIndex}): {ex.GetType().Name}: {ex.Message}\n{ex.StackTrace}");
                }
            }

            return root;
        }

        private static void BuildAtomic(RwClump clump, RwAtomic atomic, Transform[] frameTransforms,
            Transform[] boneArray, Dictionary<string, Texture2D> textures, Shader shader)
        {
            var geom = clump.Geometries[atomic.GeometryIndex];
            var parentTransform = frameTransforms[atomic.FrameIndex];

            // Atomics don't always map 1:1 with frames — some models attach several mesh
            // parts to the same frame. Give each its own child GameObject rather than piling
            // multiple Renderer components onto one shared Transform.
            var meshHolder = new GameObject($"{parentTransform.name}_mesh{atomic.GeometryIndex}");
            meshHolder.transform.SetParent(parentTransform, false);
            var hostTransform = meshHolder.transform;

            var mesh = BuildMesh(geom);
            var materials = BuildMaterials(geom, textures, shader);

            if (geom.Skin != null && boneArray.Length > 0)
            {
                AssignSkin(mesh, geom.Skin, boneArray.Length);
                var smr = hostTransform.gameObject.AddComponent<SkinnedMeshRenderer>();
                smr.bones = boneArray;
                smr.sharedMesh = mesh;
                smr.sharedMaterials = materials;
                smr.rootBone = boneArray.Length > 0 ? boneArray[0] : hostTransform;
            }
            else
            {
                var mf = hostTransform.gameObject.AddComponent<MeshFilter>();
                mf.sharedMesh = mesh;
                var mr = hostTransform.gameObject.AddComponent<MeshRenderer>();
                mr.sharedMaterials = materials;
            }
        }

        private static void ApplyLocalMatrix(Transform t, Matrix4x4 m)
        {
            // Matrix4x4.rotation is unreliable (can return garbage/NaN) for matrices that aren't
            // perfectly orthonormal — which any bone with baked-in scale will be (common for
            // mechanical/animated parts). Decompose properly instead: extract each axis's scale
            // from its column length, normalize before building the rotation, and guard against
            // divide-by-zero so a degenerate column can never produce NaN.
            Vector3 right = m.GetColumn(0);
            Vector3 up = m.GetColumn(1);
            Vector3 fwd = m.GetColumn(2);
            Vector3 pos = m.GetColumn(3);

            float sx = right.magnitude;
            float sy = up.magnitude;
            float sz = fwd.magnitude;

            const float eps = 1e-8f;
            Vector3 nFwd = sz > eps ? fwd / sz : Vector3.forward;
            Vector3 nUp = sy > eps ? up / sy : Vector3.up;

            // LookRotation requires forward/upwards not be (anti)parallel — fall back to a
            // default up vector in that rare degenerate case rather than risk a bad/NaN result.
            if (Vector3.Cross(nFwd, nUp).sqrMagnitude < eps)
                nUp = Mathf.Abs(Vector3.Dot(nFwd, Vector3.up)) > 0.99f ? Vector3.right : Vector3.up;

            Quaternion rot = Quaternion.LookRotation(nFwd, nUp);

            t.localPosition = pos;
            t.localRotation = rot;
            // Deliberately NOT applying extracted scale (sx, sy, sz) to the transform here.
            // Unity's localScale compounds multiplicatively down the hierarchy — ordinary
            // floating-point noise in the source matrix (column magnitudes like 0.99998 instead
            // of exactly 1.0) is harmless for a single bone, but across a long parent-child bone
            // chain (seen with 13-36 bone skeletons) that noise compounds exponentially into
            // wildly wrong scale, visibly stretching the whole model into a sliver. Bone
            // hierarchies should rely on bind-pose matrices for any real scaling, not cascading
            // Transform.localScale.
        }

        public static Mesh BuildMesh(RwGeometry g)
        {
            var mesh = new Mesh();
            if (g.Vertices != null && g.Vertices.Length > 65535)
                mesh.indexFormat = UnityEngine.Rendering.IndexFormat.UInt32;
            if (g.Vertices != null) mesh.vertices = g.Vertices;
            if (g.Normals != null) mesh.normals = g.Normals;
            if (g.PrelitColors != null) mesh.colors32 = g.PrelitColors;
            if (g.TexCoordSets.Count > 0) mesh.uv = g.TexCoordSets[0];
            if (g.TexCoordSets.Count > 1) mesh.uv2 = g.TexCoordSets[1];

            // Only create submeshes for matIds that actually have triangles — an empty submesh
            // produces a harmless but noisy "invalid MinMaxAABB" warning when Unity tries to
            // compute bounds for zero triangles.
            var trisByMat = new Dictionary<int, List<int>>();
            int vertCount = g.Vertices?.Length ?? 0;
            int skippedOutOfRange = 0;

            foreach (var (v1, v2, v3, matId) in g.Triangles)
            {
                if (v1 < 0 || v1 >= vertCount || v2 < 0 || v2 >= vertCount || v3 < 0 || v3 >= vertCount)
                {
                    skippedOutOfRange++;
                    continue; // out-of-range — almost certainly a chunk-parsing misalignment upstream
                }
                if (!trisByMat.TryGetValue(matId, out var list))
                    trisByMat[matId] = list = new List<int>();
                list.Add(v1); list.Add(v2); list.Add(v3);
            }

            if (skippedOutOfRange > 0)
            {
                Debug.LogWarning($"[DffImporter] Skipped {skippedOutOfRange} triangle(s) referencing out-of-range " +
                                  $"vertices (mesh has {vertCount} vertices). See the geometry misalignment warning " +
                                  "above for the likely cause.");
            }

            // Map each used matId to a submesh slot, preserving material array indices so
            // mat[matId] still lines up — Unity meshes need contiguous submesh indices 0..N-1,
            // so submesh i uses material g.Materials[usedMatIds[i]] (handled by caller via the
            // same materialCount-sized array; unused slots simply get zero triangles, which is
            // fine — only zero-triangle submeshes produce the warning, not zero-triangle materials
            // sharing a used submesh index).
            int materialCount = Mathf.Max(1, g.Materials.Count);
            mesh.subMeshCount = materialCount;
            for (int sub = 0; sub < materialCount; sub++)
            {
                // A submesh with zero triangles (a material genuinely unused by any triangle)
                // will still trigger Unity's "invalid MinMaxAABB" console warning when bounds are
                // computed for it — that's cosmetic and doesn't affect the imported mesh.
                mesh.SetTriangles(trisByMat.TryGetValue(sub, out var list) ? list : new List<int>(), sub);
            }

            if (g.Normals == null) mesh.RecalculateNormals();
            mesh.RecalculateBounds();
            return mesh;
        }

        public static Material[] BuildMaterials(RwGeometry g, Dictionary<string, Texture2D> textures, Shader shader)
        {
            int count = Mathf.Max(1, g.Materials.Count);
            var mats = new Material[count];

            for (int i = 0; i < count; i++)
            {
                var mat = new Material(shader);
                if (i < g.Materials.Count)
                {
                    var src = g.Materials[i];
                    mat.color = src.Color;
                    mat.name = string.IsNullOrEmpty(src.TextureName) ? $"Material_{i}" : src.TextureName;

                    if (!string.IsNullOrEmpty(src.TextureName) &&
                        textures != null && textures.TryGetValue(src.TextureName, out var tex))
                    {
                        if (mat.HasProperty("_BaseMap")) mat.SetTexture("_BaseMap", tex);
                        else if (mat.HasProperty("_MainTex")) mat.SetTexture("_MainTex", tex);

#if UNITY_EDITOR
                        if (tex.alphaIsTransparency)
                            EnableAlpha(mat);
#endif
                    }
                }
                else
                {
                    mat.name = $"Material_{i}";
                }
                mats[i] = mat;
            }
            return mats;
        }

        /// <summary>
        /// Configures a material for alpha cutout rendering. Handles both URP Lit and
        /// built-in Standard shaders.
        /// </summary>
        private static void EnableAlpha(Material mat)
        {
            // URP "Universal Render Pipeline/Lit"
            if (mat.HasProperty("_AlphaClip"))
            {
                mat.SetFloat("_AlphaClip", 1f);
                mat.SetFloat("_Cutoff", 0.5f);
                mat.EnableKeyword("_ALPHATEST_ON");
                mat.renderQueue = (int)UnityEngine.Rendering.RenderQueue.AlphaTest;
                // Some URP versions also need _Surface=0 (Opaque) + AlphaClip, which gives
                // alpha-tested opaque — avoids blending artefacts typical of Transparent mode.
                if (mat.HasProperty("_Surface"))
                    mat.SetFloat("_Surface", 0f);
            }
            // Built-in "Standard"
            else if (mat.HasProperty("_Mode"))
            {
                mat.SetFloat("_Mode", 1f); // Cutout
                mat.SetFloat("_Cutoff", 0.5f);
                mat.EnableKeyword("_ALPHATEST_ON");
                mat.DisableKeyword("_ALPHABLEND_ON");
                mat.DisableKeyword("_ALPHAPREMULTIPLY_ON");
                mat.renderQueue = (int)UnityEngine.Rendering.RenderQueue.AlphaTest;
            }
            // Fallback: just set render queue
            else
            {
                mat.renderQueue = (int)UnityEngine.Rendering.RenderQueue.AlphaTest;
            }
        }

        private static void AssignSkin(Mesh mesh, RwSkin skin, int boneCount)
        {
            int vertCount = mesh.vertexCount;
            var boneWeights = new BoneWeight[vertCount];

            for (int v = 0; v < vertCount; v++)
            {
                var bw = new BoneWeight();
                int baseIdx = v * 4;
                bw.boneIndex0 = skin.BoneIndices[baseIdx + 0];
                bw.boneIndex1 = skin.BoneIndices[baseIdx + 1];
                bw.boneIndex2 = skin.BoneIndices[baseIdx + 2];
                bw.boneIndex3 = skin.BoneIndices[baseIdx + 3];
                bw.weight0 = skin.BoneWeights[baseIdx + 0];
                bw.weight1 = skin.BoneWeights[baseIdx + 1];
                bw.weight2 = skin.BoneWeights[baseIdx + 2];
                bw.weight3 = skin.BoneWeights[baseIdx + 3];
                boneWeights[v] = bw;
            }
            mesh.boneWeights = boneWeights;

            var bindPoses = new Matrix4x4[boneCount];
            for (int b = 0; b < boneCount; b++)
                bindPoses[b] = b < skin.InverseBoneMatrices.Length ? skin.InverseBoneMatrices[b] : Matrix4x4.identity;
            mesh.bindposes = bindPoses;
        }
    }
}
