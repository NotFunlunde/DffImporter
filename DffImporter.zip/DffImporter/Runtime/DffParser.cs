using System;
using System.IO;
using UnityEngine;

namespace BfbbImport
{
    /// <summary>
    /// Parses a RenderWare 3.x .dff (Clump) stream into the plain data model in RwModel.cs.
    ///
    /// Scope / limitations:
    /// - Targets the generic, platform-independent RW3 chunk layout (the format used by most
    ///   PC-side BfBB modding tools and generic RW3 exporters of that era).
    /// - Does NOT handle "native" platform-packed geometry (e.g. PS2 native vertex buffers,
    ///   Xbox native geometry). If your source .dff was extracted directly from a PS2/GameCube
    ///   disc rather than a PC build, geometry chunks may be in a native binary layout this parser
    ///   does not decode — you'll get a clear exception rather than a silently-wrong mesh.
    /// - Skinning (bones) follows the standard SKIN_PLG layout (numBones, per-vertex 4x indices/weights,
    ///   inverse bone matrices). HAnim bone IDs are read from each frame's extension, if present.
    /// </summary>
    public static class DffParser
    {
        public static RwClump Parse(Stream stream)
        {
            using var r = new RwReader(stream);

            long clumpEnd = r.ReadChunkHeader(out var header);
            if (header.Type != RwChunk.CLUMP)
                throw new InvalidDataException($"Expected CLUMP chunk at root, got 0x{header.Type:X4}. " +
                                                 "This may not be a generic-format RW3 .dff, or the file is corrupt.");

            var clump = new RwClump();

            long structEnd = r.ReadChunkHeader(out var structHeader);
            if (structHeader.Type != RwChunk.STRUCT)
                throw new InvalidDataException("Expected STRUCT inside CLUMP.");
            int numAtomics = r.ReadInt32();
            r.Seek(structEnd); // skip numLights/numCameras if present — not needed for import

            long flEnd = FindChunk(r, clumpEnd, RwChunk.FRAME_LIST);
            ReadFrameList(r, flEnd, clump);
            r.Seek(flEnd);

            long glEnd = FindChunk(r, clumpEnd, RwChunk.GEOMETRY_LIST);
            ReadGeometryList(r, glEnd, clump);
            r.Seek(glEnd);

            for (int i = 0; i < numAtomics; i++)
            {
                long atEnd = FindChunk(r, clumpEnd, RwChunk.ATOMIC);
                clump.Atomics.Add(ReadAtomic(r, atEnd));
                r.Seek(atEnd);
            }

            AssignBoneIndices(clump);
            return clump;
        }

        // --- low-level helpers -------------------------------------------------

        /// <summary>Scans sibling chunks starting at the current position until one of type
        /// <paramref name="type"/> is found. Leaves the reader at the start of that chunk's body
        /// and returns the absolute offset where that chunk's body ends.</summary>
        private static long FindChunk(RwReader r, long sectionEnd, uint type)
        {
            while (r.Position < sectionEnd)
            {
                long chunkEnd = r.ReadChunkHeader(out var h);
                if (h.Type == type) return chunkEnd;
                r.Seek(chunkEnd);
            }
            throw new InvalidDataException($"Expected chunk 0x{type:X4} but reached end of section.");
        }

        // --- frame list ---------------------------------------------------------

        private static void ReadFrameList(RwReader r, long listEnd, RwClump clump)
        {
            long structEnd = r.ReadChunkHeader(out var sh);
            if (sh.Type != RwChunk.STRUCT) throw new InvalidDataException("Expected STRUCT in FRAME_LIST.");
            int numFrames = r.ReadInt32();

            for (int i = 0; i < numFrames; i++)
            {
                var f = new RwFrame();
                Vector3 right = r.ReadVector3();
                Vector3 up = r.ReadVector3();
                Vector3 at = r.ReadVector3();
                Vector3 pos = r.ReadVector3();
                f.ParentIndex = r.ReadInt32();
                r.ReadUInt32(); // creation flags, unused

                var m = Matrix4x4.identity;
                m.SetColumn(0, new Vector4(right.x, right.y, right.z, 0));
                m.SetColumn(1, new Vector4(up.x, up.y, up.z, 0));
                m.SetColumn(2, new Vector4(at.x, at.y, at.z, 0));
                m.SetColumn(3, new Vector4(pos.x, pos.y, pos.z, 1));
                f.LocalMatrix = m;

                clump.Frames.Add(f);
            }
            r.Seek(structEnd);

            for (int i = 0; i < numFrames && r.Position < listEnd; i++)
            {
                long extEnd = r.ReadChunkHeader(out var eh);
                if (eh.Type != RwChunk.EXTENSION)
                    return; // layout mismatch — stop rather than guess

                ParseFrameExtension(r, extEnd, clump.Frames[i], clump);
                r.Seek(extEnd);
            }
        }

        private static void ParseFrameExtension(RwReader r, long extEnd, RwFrame frame, RwClump clump)
        {
            while (r.Position < extEnd)
            {
                long chunkEnd = r.ReadChunkHeader(out var h);
                if (h.Type == RwChunk.STRING)
                {
                    frame.Name = r.ReadFixedString((int)h.Size);
                }
                else if (h.Type == RwChunk.HANIM_PLG)
                {
                    r.ReadInt32(); // version, unused
                    frame.BoneId = r.ReadInt32();
                    int numBonesInTable = r.ReadInt32();

                    // Only the skeleton ROOT's HAnim chunk carries this table (numBonesInTable > 0).
                    // It maps each bone's "id" tag to the literal index Skin PLG data refers to —
                    // this is the authoritative source, NOT frame-list order.
                    if (numBonesInTable > 0)
                    {
                        r.ReadInt32(); // flags, unused
                        r.ReadInt32(); // keyframe size, unused
                        for (int b = 0; b < numBonesInTable; b++)
                        {
                            int boneId = r.ReadInt32();
                            int boneIndex = r.ReadInt32();
                            r.ReadInt32(); // type, unused
                            clump.HAnimIndexById[boneId] = boneIndex;
                        }
                    }
                }
                r.Seek(chunkEnd);
            }
        }

        // --- geometry list --------------------------------------------------------

        private static void ReadGeometryList(RwReader r, long listEnd, RwClump clump)
        {
            long structEnd = r.ReadChunkHeader(out var sh);
            if (sh.Type != RwChunk.STRUCT) throw new InvalidDataException("Expected STRUCT in GEOMETRY_LIST.");
            int numGeometries = r.ReadInt32();
            r.Seek(structEnd);

            for (int i = 0; i < numGeometries; i++)
            {
                long geomEnd = r.ReadChunkHeader(out var gh);
                if (gh.Type != RwChunk.GEOMETRY)
                    throw new InvalidDataException($"Expected GEOMETRY chunk, got 0x{gh.Type:X4}.");
                clump.Geometries.Add(ReadGeometry(r, geomEnd));
                r.Seek(geomEnd);
            }
        }

        private const uint FLAG_TEXTURED = 0x00000004;
        private const uint FLAG_PRELIT = 0x00000008;
        private const uint FLAG_TEXTURED2 = 0x00000080;
        private const uint FLAG_NATIVE = 0x01000000;

        private static RwGeometry ReadGeometry(RwReader r, long geomEnd)
        {
            var g = new RwGeometry();

            long structEnd = r.ReadChunkHeader(out var sh);
            if (sh.Type != RwChunk.STRUCT) throw new InvalidDataException("Expected STRUCT in GEOMETRY.");

            uint flags = r.ReadUInt32();
            g.Flags = flags;
            int numTriangles = r.ReadInt32();
            int numVertices = r.ReadInt32();
            int numMorphTargets = r.ReadInt32();

            int numTexSets = (int)((flags >> 16) & 0xFF);
            if (numTexSets == 0 && (flags & (FLAG_TEXTURED | FLAG_TEXTURED2)) != 0)
                numTexSets = 1;

            bool isNative = (flags & FLAG_NATIVE) != 0;

            // Non-native block: prelit colors, then UV sets, then triangles — all absent for
            // native (pre-instanced) geometry, which this importer doesn't support decoding.
            if (!isNative)
            {
                if ((flags & FLAG_PRELIT) != 0)
                {
                    g.PrelitColors = new Color32[numVertices];
                    for (int v = 0; v < numVertices; v++)
                    {
                        byte cr = r.ReadByte(), cg = r.ReadByte(), cb = r.ReadByte(), ca = r.ReadByte();
                        g.PrelitColors[v] = new Color32(cr, cg, cb, ca);
                    }
                }

                for (int t = 0; t < numTexSets; t++)
                {
                    var uvs = new Vector2[numVertices];
                    for (int v = 0; v < numVertices; v++)
                    {
                        var uv = r.ReadVector2();
                        uv.y = 1f - uv.y; // RW V is flipped relative to Unity
                        uvs[v] = uv;
                    }
                    g.TexCoordSets.Add(uvs);
                }

                for (int t = 0; t < numTriangles; t++)
                {
                    ushort v2 = r.ReadUInt16();
                    ushort v1 = r.ReadUInt16();
                    ushort matId = r.ReadUInt16();
                    ushort v3 = r.ReadUInt16();
                    g.Triangles.Add((v1, v2, v3, matId));
                }
            }

            // Morph targets: bounding sphere + hasVertices/hasNormals bools + the actual data.
            // This comes AFTER the block above, not before — only morph target 0 is kept.
            int morphIterations = Math.Max(numMorphTargets, 1);
            for (int m = 0; m < morphIterations; m++)
            {
                if (numMorphTargets > 0)
                {
                    r.ReadFloat(); r.ReadFloat(); r.ReadFloat(); r.ReadFloat(); // bounding sphere
                    int hasVertices = r.ReadInt32();
                    int hasNormals = r.ReadInt32();

                    if (m == 0)
                    {
                        if (hasVertices != 0)
                        {
                            g.Vertices = new Vector3[numVertices];
                            for (int v = 0; v < numVertices; v++) g.Vertices[v] = r.ReadVector3();
                        }
                        if (hasNormals != 0)
                        {
                            g.Normals = new Vector3[numVertices];
                            for (int v = 0; v < numVertices; v++) g.Normals[v] = r.ReadVector3();
                        }
                    }
                    else
                    {
                        if (hasVertices != 0) r.Skip(12L * numVertices);
                        if (hasNormals != 0) r.Skip(12L * numVertices);
                    }
                }
            }

            if (r.Position != structEnd)
            {
                Debug.LogWarning($"[DffImporter] Geometry struct misaligned: read up to byte {r.Position}, " +
                                  $"chunk declares end at {structEnd} (delta {structEnd - r.Position} bytes). " +
                                  $"flags=0x{flags:X8} numVerts={numVertices} numTris={numTriangles} " +
                                  $"numMorphTargets={numMorphTargets} numTexSets={numTexSets} " +
                                  $"prelit={(flags & FLAG_PRELIT) != 0}. " +
                                  "Triangle data for this geometry was very likely read from the wrong offset — " +
                                  "please report these exact numbers if you see this.");
            }
            r.Seek(structEnd);
            long matListEnd = FindChunk(r, geomEnd, RwChunk.MATERIAL_LIST);
            ReadMaterialList(r, matListEnd, g);
            r.Seek(matListEnd);

            if (r.Position < geomEnd)
            {
                long peekPos = r.Position;
                long extEnd = r.ReadChunkHeader(out var eh);
                if (eh.Type == RwChunk.EXTENSION)
                    ParseGeometryExtension(r, extEnd, g, numVertices);
                else
                    r.Seek(peekPos);
            }

            return g;
        }

        private static void ReadMaterialList(RwReader r, long listEnd, RwGeometry g)
        {
            long structEnd = r.ReadChunkHeader(out var sh);
            if (sh.Type != RwChunk.STRUCT) throw new InvalidDataException("Expected STRUCT in MATERIAL_LIST.");
            int numMaterials = r.ReadInt32();
            var sharedIndices = new int[numMaterials];
            for (int i = 0; i < numMaterials; i++) sharedIndices[i] = r.ReadInt32();
            r.Seek(structEnd);

            for (int i = 0; i < numMaterials; i++)
            {
                if (sharedIndices[i] >= 0)
                {
                    if (sharedIndices[i] < g.Materials.Count)
                        g.Materials.Add(g.Materials[sharedIndices[i]]);
                    else
                        Debug.LogWarning($"[DffImporter] Shared material index {sharedIndices[i]} is out of range " +
                                          $"(only {g.Materials.Count} materials so far). Adding a default material.");
                    continue;
                }
                long matEnd = r.ReadChunkHeader(out var mh);
                if (mh.Type != RwChunk.MATERIAL) throw new InvalidDataException("Expected MATERIAL chunk.");
                g.Materials.Add(ReadMaterial(r, matEnd));
                r.Seek(matEnd);
            }
        }

        private static RwMaterial ReadMaterial(RwReader r, long matEnd)
        {
            var mat = new RwMaterial();

            long structEnd = r.ReadChunkHeader(out var sh);
            if (sh.Type != RwChunk.STRUCT) throw new InvalidDataException("Expected STRUCT in MATERIAL.");

            r.ReadUInt32(); // flags, unused
            byte cr = r.ReadByte(), cg = r.ReadByte(), cb = r.ReadByte(), ca = r.ReadByte();
            mat.Color = new Color32(cr, cg, cb, ca);
            r.ReadInt32(); // unused
            int isTextured = r.ReadInt32();
            r.ReadFloat(); r.ReadFloat(); r.ReadFloat(); // ambient, specular, diffuse
            r.Seek(structEnd);

            if (isTextured != 0)
            {
                long texEnd = FindChunk(r, matEnd, RwChunk.TEXTURE);
                ReadTextureChunk(r, texEnd, mat);
                r.Seek(texEnd);
            }

            return mat;
        }

        private static void ReadTextureChunk(RwReader r, long texEnd, RwMaterial mat)
        {
            long structEnd = r.ReadChunkHeader(out var sh);
            if (sh.Type != RwChunk.STRUCT) throw new InvalidDataException("Expected STRUCT in TEXTURE.");
            r.ReadUInt32(); // filter/addressing mode, not needed for import
            r.Seek(structEnd);

            long nameEnd = r.ReadChunkHeader(out var nh);
            if (nh.Type == RwChunk.STRING) mat.TextureName = r.ReadFixedString((int)nh.Size);
            r.Seek(nameEnd);

            if (r.Position < texEnd)
            {
                long maskEnd = r.ReadChunkHeader(out var mh2);
                if (mh2.Type == RwChunk.STRING) mat.MaskName = r.ReadFixedString((int)mh2.Size);
                r.Seek(maskEnd);
            }
        }

        private static void ParseGeometryExtension(RwReader r, long extEnd, RwGeometry g, int numVertices)
        {
            while (r.Position < extEnd)
            {
                long chunkEnd = r.ReadChunkHeader(out var h);
                if (h.Type == RwChunk.SKIN_PLG)
                    g.Skin = ReadSkin(r, numVertices);
                r.Seek(chunkEnd);
            }
        }

        private static RwSkin ReadSkin(RwReader r, int numVertices)
        {
            var skin = new RwSkin();
            byte numBones = r.ReadByte();
            byte numUsedBones = r.ReadByte();
            r.ReadByte(); // max weights per vertex, unused
            r.ReadByte(); // padding

            skin.NumBones = numBones;

            if (numUsedBones > 0)
                r.Skip(numUsedBones); // used-bone index table — not needed for direct array binding

            skin.BoneIndices = new byte[4 * numVertices];
            for (int i = 0; i < 4 * numVertices; i++) skin.BoneIndices[i] = r.ReadByte();

            skin.BoneWeights = new float[4 * numVertices];
            for (int i = 0; i < 4 * numVertices; i++) skin.BoneWeights[i] = r.ReadFloat();

            skin.InverseBoneMatrices = new Matrix4x4[numBones];
            for (int b = 0; b < numBones; b++)
            {
                // RW stores matrices in row-vector convention (v' = v * M); Unity uses
                // column-vector convention (v' = M * v). The file's 16 floats are in row-major
                // order, so we transpose on read by swapping [row,col] to [col,row].
                var m = new Matrix4x4();
                for (int row = 0; row < 4; row++)
                    for (int col = 0; col < 4; col++)
                        m[col, row] = r.ReadFloat();

                // In RW's row-vector layout the 4th element of each basis row (now in Unity's
                // last row after the transpose) can contain junk. Force it to (0,0,0,1).
                m[3, 0] = 0f;
                m[3, 1] = 0f;
                m[3, 2] = 0f;
                m[3, 3] = 1f;

                skin.InverseBoneMatrices[b] = m;
            }

            return skin;
        }

        // --- atomics ---------------------------------------------------------------

        private static RwAtomic ReadAtomic(RwReader r, long atomicEnd)
        {
            long structEnd = r.ReadChunkHeader(out var sh);
            if (sh.Type != RwChunk.STRUCT) throw new InvalidDataException("Expected STRUCT in ATOMIC.");

            var a = new RwAtomic
            {
                FrameIndex = r.ReadInt32(),
                GeometryIndex = r.ReadInt32()
            };
            r.Seek(structEnd);
            return a;
        }

        private static void AssignBoneIndices(RwClump clump)
        {
            bool haveTable = clump.HAnimIndexById.Count > 0;

            foreach (var f in clump.Frames)
            {
                if (f.BoneId < 0) continue;

                if (haveTable && clump.HAnimIndexById.TryGetValue(f.BoneId, out int idx))
                    f.BoneIndex = idx;
                else
                    // No root table (or this id isn't in it) — the bone's own id tag IS the skin
                    // index directly in that case, NOT its position in the frame list. Frame-list
                    // order is not guaranteed to match id order (confirmed by real files where the
                    // ids appear as a permutation, not a sequential count, across the frame list).
                    f.BoneIndex = f.BoneId;
            }
        }
    }
}
