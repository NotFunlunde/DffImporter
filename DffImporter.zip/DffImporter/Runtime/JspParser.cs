using System;
using System.Collections.Generic;
using System.IO;
using UnityEngine;

namespace BfbbImport
{
    /// <summary>
    /// Parsed result of a RenderWare World/BSP file (.jsp).
    /// Contains one RwGeometry per atomic (leaf) sector, sharing a common material list.
    /// </summary>
    public class RwWorld
    {
        public List<RwMaterial> Materials = new List<RwMaterial>();
        public List<RwGeometry> Sectors = new List<RwGeometry>();
        public uint Format;
    }

    /// <summary>
    /// Parses RenderWare 3.x World/BSP files (.jsp) used for static level geometry
    /// in BfBB, Scooby-Doo, and other Heavy Iron games.
    ///
    /// The format is a BSP tree of plane sectors (internal nodes) and atomic sectors
    /// (leaf nodes containing actual geometry). Materials are shared across all sectors
    /// via a single MATERIAL_LIST in the World chunk.
    ///
    /// This parser handles the generic (non-native) vertex layout. Platform-packed
    /// (native) geometry is detected and skipped with a warning.
    /// </summary>
    public static class JspParser
    {
        private const uint FLAG_TEXTURED = 0x00000004;
        private const uint FLAG_PRELIT = 0x00000008;
        private const uint FLAG_NORMALS = 0x00000010;
        private const uint FLAG_TEXTURED2 = 0x00000080;
        private const uint FLAG_NATIVE = 0x01000000;

        private const uint BEEF_MAGIC = 0x00BEEF01;

        public static RwWorld Parse(Stream stream)
        {
            using var r = new RwReader(stream);

            // Heavy Iron .jsp files are wrapped in a BEEF01 container that holds
            // the BSP node tree before the actual RenderWare World chunk.  Detect
            // this wrapper and skip past it to find the embedded World data.
            long worldEnd = SeekToWorldChunk(r);
            var header = new RwChunkHeader { Type = RwChunk.WORLD }; // already validated

            var world = new RwWorld();

            // ── World STRUCT ──
            long structEnd = r.ReadChunkHeader(out var sh);
            if (sh.Type != RwChunk.STRUCT)
                throw new InvalidDataException("Expected STRUCT inside WORLD.");

            ReadWorldStruct(r, sh.Size, world);
            r.Seek(structEnd);

            if ((world.Format & FLAG_NATIVE) != 0)
            {
                Debug.LogWarning("[JspParser] World uses native (platform-packed) geometry. " +
                                 "Only generic-format .jsp files are supported.");
                return world;
            }

            // ── MATERIAL_LIST ──
            long matListEnd = FindChunk(r, worldEnd, RwChunk.MATERIAL_LIST);
            ReadMaterialList(r, matListEnd, world);
            r.Seek(matListEnd);

            // ── BSP tree (plane sectors + atomic sectors) ──
            WalkBspTree(r, worldEnd, world);

            return world;
        }

        // ────────────────────────── BEEF01 / World locator ──────────────────────────

        /// <summary>
        /// Finds and positions the reader at the start of the RW World chunk body.
        /// Returns the absolute stream offset where the World chunk ends.
        ///
        /// Handles three cases:
        ///   1. Raw RW World file — starts with chunk type 0x000B.
        ///   2. Heavy Iron BEEF01 wrapper — scans past the node table to the World chunk.
        ///   3. Unknown wrapper — scans 4-byte-aligned positions for the World chunk header.
        /// </summary>
        private static long SeekToWorldChunk(RwReader r)
        {
            long startPos = r.Position;
            uint firstWord = r.ReadUInt32();

            if (firstWord == RwChunk.WORLD)
            {
                // Case 1: raw RW World — read rest of header.
                uint size = r.ReadUInt32();
                r.ReadUInt32(); // libraryId
                return r.Position + size;
            }

            // Case 2 / 3: scan for the World chunk from current position.
            // For BEEF01 containers the World chunk follows immediately after
            // the node table, but we do a general scan so any wrapper works.
            r.Seek(startPos);
            return ScanForWorldChunk(r);
        }

        private static long ScanForWorldChunk(RwReader r)
        {
            long len = r.Length;

            // Scan at 4-byte-aligned positions (RW chunks are always aligned).
            while (r.Position + 12 <= len)
            {
                long candidatePos = r.Position;
                uint type = r.ReadUInt32();

                if (type == RwChunk.WORLD)
                {
                    uint size = r.ReadUInt32();
                    uint libId = r.ReadUInt32();

                    // Validate: size must fit in the remaining stream, and the library
                    // ID should look like a RW 3.x version (0x0003xxxx or similar).
                    long endPos = r.Position + size;
                    if (endPos <= len && size >= 40)
                    {
                        // Found a plausible World chunk.
                        return endPos;
                    }
                }

                // Advance by 4 bytes from the candidate position.
                r.Seek(candidatePos + 4);
            }

            throw new InvalidDataException(
                "Could not locate a RenderWare WORLD chunk (0x000B) in this file. " +
                "It may not be a supported JSP/BSP file.");
        }

        // ────────────────────────── World header ──────────────────────────

        private static void ReadWorldStruct(RwReader r, uint structSize, RwWorld world)
        {
            // Layout varies by RW version:
            //   RW 3.2-:  rootIsWorldSector(4) + invOrigin(12) + numTri(4) + numVert(4) +
            //             numPlane(4) + numAtomic(4) + colSize(4) + format(4) = 40 bytes
            //   RW 3.3+:  adds ambient(4) + specular(4) + diffuse(4) after invOrigin = 52 bytes
            // We detect by struct size and skip to the format field.

            r.ReadInt32(); // rootIsWorldSector
            r.ReadFloat(); r.ReadFloat(); r.ReadFloat(); // invWorldOrigin

            if (structSize >= 52)
                r.Skip(12); // ambient, specular, diffuse (surface properties, RW 3.3+)

            r.ReadInt32(); // numTriangles (total)
            r.ReadInt32(); // numVertices (total)
            r.ReadInt32(); // numPlaneSectors
            r.ReadInt32(); // numWorldSectors (atomic)
            r.ReadInt32(); // colSectorSize

            world.Format = r.ReadUInt32();
        }

        // ────────────────────────── Material list ──────────────────────────

        private static void ReadMaterialList(RwReader r, long listEnd, RwWorld world)
        {
            long structEnd = r.ReadChunkHeader(out var sh);
            if (sh.Type != RwChunk.STRUCT)
                throw new InvalidDataException("Expected STRUCT in MATERIAL_LIST.");

            int numMaterials = r.ReadInt32();
            var sharedIndices = new int[numMaterials];
            for (int i = 0; i < numMaterials; i++) sharedIndices[i] = r.ReadInt32();
            r.Seek(structEnd);

            for (int i = 0; i < numMaterials; i++)
            {
                if (sharedIndices[i] >= 0)
                {
                    if (sharedIndices[i] < world.Materials.Count)
                        world.Materials.Add(world.Materials[sharedIndices[i]]);
                    else
                        world.Materials.Add(new RwMaterial());
                    continue;
                }

                long matEnd = r.ReadChunkHeader(out var mh);
                if (mh.Type != RwChunk.MATERIAL)
                    throw new InvalidDataException("Expected MATERIAL chunk.");
                world.Materials.Add(ReadMaterial(r, matEnd));
                r.Seek(matEnd);
            }
        }

        private static RwMaterial ReadMaterial(RwReader r, long matEnd)
        {
            var mat = new RwMaterial();

            long structEnd = r.ReadChunkHeader(out var sh);
            if (sh.Type != RwChunk.STRUCT)
                throw new InvalidDataException("Expected STRUCT in MATERIAL.");

            r.ReadUInt32(); // flags
            byte cr = r.ReadByte(), cg = r.ReadByte(), cb = r.ReadByte(), ca = r.ReadByte();
            mat.Color = new Color32(cr, cg, cb, ca);
            r.ReadInt32(); // unused
            int isTextured = r.ReadInt32();
            r.ReadFloat(); r.ReadFloat(); r.ReadFloat(); // ambient, specular, diffuse
            r.Seek(structEnd);

            if (isTextured != 0)
            {
                long texEnd = FindChunk(r, matEnd, RwChunk.TEXTURE);
                ReadTextureChunk(r, texEnd, mat);
                r.Seek(texEnd);
            }

            return mat;
        }

        private static void ReadTextureChunk(RwReader r, long texEnd, RwMaterial mat)
        {
            long structEnd = r.ReadChunkHeader(out var sh);
            if (sh.Type != RwChunk.STRUCT)
                throw new InvalidDataException("Expected STRUCT in TEXTURE.");
            r.ReadUInt32(); // filter/addressing mode
            r.Seek(structEnd);

            long nameEnd = r.ReadChunkHeader(out var nh);
            if (nh.Type == RwChunk.STRING)
                mat.TextureName = r.ReadFixedString((int)nh.Size);
            r.Seek(nameEnd);

            if (r.Position < texEnd)
            {
                long maskEnd = r.ReadChunkHeader(out var mh);
                if (mh.Type == RwChunk.STRING)
                    mat.MaskName = r.ReadFixedString((int)mh.Size);
                r.Seek(maskEnd);
            }
        }

        // ────────────────────────── BSP tree walk ──────────────────────────

        private static void WalkBspTree(RwReader r, long parentEnd, RwWorld world)
        {
            while (r.Position < parentEnd)
            {
                long chunkEnd = r.ReadChunkHeader(out var h);

                if (h.Type == RwChunk.ATOMIC_SECTOR)
                {
                    var sector = ReadAtomicSector(r, chunkEnd, world);
                    if (sector != null && sector.Vertices != null && sector.Vertices.Length > 0)
                        world.Sectors.Add(sector);
                }
                else if (h.Type == RwChunk.PLANE_SECTOR)
                {
                    // Plane sector STRUCT: sectorType(4) + value(4) + leftIsAtomic(4) +
                    // rightIsAtomic(4) + leftValue(4) + rightValue(4) = 24 bytes
                    long psStructEnd = r.ReadChunkHeader(out var psh);
                    r.Seek(psStructEnd); // skip the plane data — we just need the children

                    // Recurse into left and right children.
                    WalkBspTree(r, chunkEnd, world);
                }
                else
                {
                    // Unknown sibling chunk — skip it.
                }

                r.Seek(chunkEnd);
            }
        }

        // ────────────────────────── Atomic sector ──────────────────────────

        private static RwGeometry ReadAtomicSector(RwReader r, long sectorEnd, RwWorld world)
        {
            long structEnd = r.ReadChunkHeader(out var sh);
            if (sh.Type != RwChunk.STRUCT)
                throw new InvalidDataException("Expected STRUCT in ATOMIC_SECTOR.");

            int matListWindowBase = r.ReadInt32();
            int numTriangles = r.ReadInt32();
            int numVertices = r.ReadInt32();

            // Bounding box (6 floats: min xyz, max xyz).
            r.ReadFloat(); r.ReadFloat(); r.ReadFloat();
            r.ReadFloat(); r.ReadFloat(); r.ReadFloat();

            if (numVertices == 0 && numTriangles == 0)
            {
                r.Seek(structEnd);
                return null;
            }

            // Detect whether there are 2 extra padding int32s after the bounding box.
            // Compute expected vertex data size and compare with remaining struct bytes.
            uint format = world.Format;
            int numTexSets = (int)((format >> 16) & 0xFF);
            if (numTexSets == 0 && (format & (FLAG_TEXTURED | FLAG_TEXTURED2)) != 0)
                numTexSets = 1;

            long bytesRead = r.Position - (structEnd - sh.Size); // bytes consumed so far in this struct
            long remaining = structEnd - r.Position;

            int vertexDataSize = numVertices * 12; // positions
            if ((format & FLAG_NORMALS) != 0) vertexDataSize += numVertices * 12;
            if ((format & FLAG_PRELIT) != 0) vertexDataSize += numVertices * 4;
            vertexDataSize += numVertices * 8 * numTexSets;
            int triangleDataSize = numTriangles * 8;
            int totalDataSize = vertexDataSize + triangleDataSize;

            // If remaining > totalDataSize, skip the extra header bytes (padding fields).
            long extraHeader = remaining - totalDataSize;
            if (extraHeader > 0 && extraHeader <= 16)
                r.Skip(extraHeader);

            var g = new RwGeometry();
            g.Flags = format;

            // Vertices (always present when numVertices > 0).
            g.Vertices = new Vector3[numVertices];
            for (int v = 0; v < numVertices; v++)
                g.Vertices[v] = r.ReadVector3();

            // Normals.
            if ((format & FLAG_NORMALS) != 0)
            {
                g.Normals = new Vector3[numVertices];
                for (int v = 0; v < numVertices; v++)
                    g.Normals[v] = r.ReadVector3();
            }

            // Prelit colors.
            if ((format & FLAG_PRELIT) != 0)
            {
                g.PrelitColors = new Color32[numVertices];
                for (int v = 0; v < numVertices; v++)
                {
                    byte cr = r.ReadByte(), cg = r.ReadByte(), cb = r.ReadByte(), ca = r.ReadByte();
                    g.PrelitColors[v] = new Color32(cr, cg, cb, ca);
                }
            }

            // Texture coordinates.
            for (int t = 0; t < numTexSets; t++)
            {
                var uvs = new Vector2[numVertices];
                for (int v = 0; v < numVertices; v++)
                {
                    var uv = r.ReadVector2();
                    uv.y = 1f - uv.y; // RW V → Unity V
                    uvs[v] = uv;
                }
                g.TexCoordSets.Add(uvs);
            }

            // Triangles: (v2, v1, matId, v3) — same layout as Geometry triangles.
            for (int t = 0; t < numTriangles; t++)
            {
                ushort v2 = r.ReadUInt16();
                ushort v1 = r.ReadUInt16();
                ushort matId = r.ReadUInt16();
                ushort v3 = r.ReadUInt16();
                g.Triangles.Add((v1, v2, v3, matId + matListWindowBase));
            }

            r.Seek(structEnd);

            // Assign materials from the world's shared list.
            // Each sector references a window into the world material list via matListWindowBase.
            // We copy the full material list so BuildMesh/BuildMaterials can index directly.
            g.Materials.AddRange(world.Materials);

            return g;
        }

        // ────────────────────────── Helpers ──────────────────────────

        private static long FindChunk(RwReader r, long sectionEnd, uint type)
        {
            while (r.Position < sectionEnd)
            {
                long chunkEnd = r.ReadChunkHeader(out var h);
                if (h.Type == type) return chunkEnd;
                r.Seek(chunkEnd);
            }
            throw new InvalidDataException($"Expected chunk 0x{type:X4} but reached end of section.");
        }
    }
}
