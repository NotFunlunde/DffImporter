using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace BfbbImport
{
    /// <summary>
    /// Identifies which Heavy Iron game produced the HIP/HOP archive.
    /// Affects entity data layout (BfBB has a 4-byte pad that Scooby doesn't).
    /// </summary>
    public enum HipGame
    {
        Unknown,
        Scooby,
        BFBB,
        Incredibles
    }

    /// <summary>Target platform — determines asset data endianness.</summary>
    public enum HipPlatform
    {
        Unknown,
        PS2,
        GameCube,
        Xbox
    }

    /// <summary>Lightweight descriptor for one asset inside a HIP/HOP archive.</summary>
    public struct HipAsset
    {
        public uint AssetId;
        public string TypeCode;  // 4-char code: SIMP, MODL, RWTX, BUTN, etc.
        public string Name;
        public byte[] Data;
    }

    /// <summary>One layer entry from the LTOC section.</summary>
    public struct HipLayer
    {
        public int LayerType;
        public uint[] AssetIds;
    }

    /// <summary>
    /// Result of parsing a HIP/HOP file.
    /// Contains every asset's raw data plus detected game/platform metadata.
    /// </summary>
    public class HipHopFile
    {
        public HipGame Game;
        public HipPlatform Platform;
        public List<HipAsset> Assets = new List<HipAsset>();
        public List<HipLayer> Layers = new List<HipLayer>();

        /// <summary>Lookup asset by ID. Returns null data if not found.</summary>
        public HipAsset? FindAsset(uint id)
        {
            for (int i = 0; i < Assets.Count; i++)
                if (Assets[i].AssetId == id)
                    return Assets[i];
            return null;
        }
    }

    /// <summary>
    /// Parses Heavy Iron Studios HIP/HOP archive files (BfBB, Incredibles, Scooby-Doo).
    ///
    /// HIP/HOP archives use a nested section structure with big-endian headers:
    ///   HIPA > PACK (game/platform info) > DICT (asset + layer tables) > STRM (raw data) > HIPB
    ///
    /// Asset data bytes use platform-native endianness (Xbox/PS2 = little-endian,
    /// GameCube = big-endian). This parser extracts the raw bytes without interpreting
    /// them — the caller decides how to decode each asset type.
    ///
    /// Reference: github.com/igorseabra4/IndustrialPark (HipHopFile library).
    /// </summary>
    public static class HipHopParser
    {
        public static HipHopFile Parse(string filePath)
        {
            using var fs = new FileStream(filePath, FileMode.Open, FileAccess.Read);
            return Parse(fs);
        }

        public static HipHopFile Parse(Stream stream)
        {
            var result = new HipHopFile();
            using var br = new BinaryReader(stream, Encoding.ASCII, leaveOpen: true);

            // Temp storage: AHDR entries reference data by absolute file offset,
            // so we parse the headers first and read data bytes in a second pass.
            var assetHeaders = new List<(uint id, string typeCode, int fileOffset, int fileSize, string name)>();

            while (br.BaseStream.Position < br.BaseStream.Length)
            {
                string sectionTag = ReadTag(br);
                int sectionSize = ReadBigEndianInt32(br);
                long sectionEnd = br.BaseStream.Position + sectionSize;

                switch (sectionTag)
                {
                    case "HIPA":
                        // No payload we need.
                        break;

                    case "PACK":
                        ParsePack(br, sectionEnd, result);
                        break;

                    case "DICT":
                        ParseDict(br, sectionEnd, result, assetHeaders);
                        break;

                    case "STRM":
                        // The stream section — asset data lives here at absolute offsets.
                        // We skip it; data is read via seeks below.
                        break;

                    case "HIPB":
                        // Footer — nothing needed.
                        break;
                }

                br.BaseStream.Position = sectionEnd;
            }

            // Second pass: read asset data bytes by seeking to each AHDR's fileOffset.
            foreach (var (id, typeCode, fileOffset, fileSize, name) in assetHeaders)
            {
                byte[] data = null;
                if (fileOffset >= 0 && fileSize > 0 && fileOffset + fileSize <= br.BaseStream.Length)
                {
                    br.BaseStream.Position = fileOffset;
                    data = br.ReadBytes(fileSize);
                }

                result.Assets.Add(new HipAsset
                {
                    AssetId = id,
                    TypeCode = typeCode,
                    Name = name ?? $"asset_{id:X8}",
                    Data = data ?? Array.Empty<byte>()
                });
            }

            return result;
        }

        // ──────────────────────────── PACK ────────────────────────────

        private static void ParsePack(BinaryReader br, long packEnd, HipHopFile result)
        {
            HipGame game = HipGame.Unknown;

            while (br.BaseStream.Position < packEnd)
            {
                string tag = ReadTag(br);
                int size = ReadBigEndianInt32(br);
                long end = br.BaseStream.Position + size;

                switch (tag)
                {
                    case "PVER":
                    {
                        int subVersion = ReadBigEndianInt32(br);
                        int clientVersion = ReadBigEndianInt32(br);
                        int compatible = ReadBigEndianInt32(br);

                        if (clientVersion == 262150)
                            game = HipGame.Scooby;
                        else if (clientVersion == 655375)
                            game = HipGame.BFBB; // may be upgraded to Incredibles by PFLG
                        break;
                    }

                    case "PFLG":
                    {
                        int flags = ReadBigEndianInt32(br);
                        if (flags == 0x2E && game == HipGame.BFBB)
                            game = HipGame.Incredibles;
                        break;
                    }

                    case "PLAT":
                        ParsePlat(br, end, game, result);
                        break;
                }

                result.Game = game;
                br.BaseStream.Position = end;
            }
        }

        private static void ParsePlat(BinaryReader br, long platEnd, HipGame game, HipHopFile result)
        {
            // PLAT contains null-terminated, 2-byte-aligned strings.
            // First string is the platform code (e.g. "XB", "GC", "P2").
            string targetPlatform = ReadPaddedString(br);

            if (targetPlatform == "XB" || targetPlatform == "BX")
                result.Platform = HipPlatform.Xbox;
            else if (targetPlatform == "GC")
                result.Platform = HipPlatform.GameCube;
            else if (targetPlatform == "P2" || targetPlatform == "PS2")
                result.Platform = HipPlatform.PS2;

            // If first string didn't match, try the second (platformName like "Xbox", "GameCube").
            if (result.Platform == HipPlatform.Unknown)
            {
                string targetPlatformName = ReadPaddedString(br);
                if (targetPlatformName == "Xbox")
                    result.Platform = HipPlatform.Xbox;
                else if (targetPlatformName == "GameCube")
                    result.Platform = HipPlatform.GameCube;
                else if (targetPlatformName == "PlayStation 2")
                    result.Platform = HipPlatform.PS2;
            }
        }

        // ──────────────────────────── DICT ────────────────────────────

        private static void ParseDict(BinaryReader br, long dictEnd, HipHopFile result,
            List<(uint, string, int, int, string)> assetHeaders)
        {
            while (br.BaseStream.Position < dictEnd)
            {
                string tag = ReadTag(br);
                int size = ReadBigEndianInt32(br);
                long end = br.BaseStream.Position + size;

                switch (tag)
                {
                    case "ATOC":
                        ParseATOC(br, end, assetHeaders);
                        break;
                    case "LTOC":
                        ParseLTOC(br, end, result);
                        break;
                }

                br.BaseStream.Position = end;
            }
        }

        private static void ParseATOC(BinaryReader br, long atocEnd,
            List<(uint, string, int, int, string)> assetHeaders)
        {
            // ATOC header: skip its own AINF sub-section.
            while (br.BaseStream.Position < atocEnd)
            {
                string tag = ReadTag(br);
                int size = ReadBigEndianInt32(br);
                long end = br.BaseStream.Position + size;

                if (tag == "AINF")
                {
                    br.BaseStream.Position = end;
                    continue;
                }

                if (tag == "AHDR")
                {
                    uint assetId = ReadBigEndianUInt32(br);
                    string typeCode = ReadTag(br);
                    int fileOffset = ReadBigEndianInt32(br);
                    int fileSize = ReadBigEndianInt32(br);
                    int plusValue = ReadBigEndianInt32(br);
                    int flags = ReadBigEndianInt32(br);

                    // ADBG sub-section: contains asset name.
                    string assetName = null;
                    string adbgTag = ReadTag(br);
                    int adbgSize = ReadBigEndianInt32(br);
                    long adbgEnd = br.BaseStream.Position + adbgSize;
                    if (adbgTag == "ADBG")
                    {
                        int alignment = ReadBigEndianInt32(br);
                        assetName = ReadPaddedString(br);
                    }
                    br.BaseStream.Position = adbgEnd;

                    assetHeaders.Add((assetId, typeCode, fileOffset, fileSize, assetName));
                }

                br.BaseStream.Position = end;
            }
        }

        private static void ParseLTOC(BinaryReader br, long ltocEnd, HipHopFile result)
        {
            while (br.BaseStream.Position < ltocEnd)
            {
                string tag = ReadTag(br);
                int size = ReadBigEndianInt32(br);
                long end = br.BaseStream.Position + size;

                if (tag == "LINF")
                {
                    br.BaseStream.Position = end;
                    continue;
                }

                if (tag == "LHDR")
                {
                    int layerType = ReadBigEndianInt32(br);
                    int assetCount = ReadBigEndianInt32(br);
                    var ids = new uint[assetCount];
                    for (int i = 0; i < assetCount; i++)
                        ids[i] = ReadBigEndianUInt32(br);

                    result.Layers.Add(new HipLayer { LayerType = layerType, AssetIds = ids });

                    // Skip LDBG sub-section (layer debug info).
                }

                br.BaseStream.Position = end;
            }
        }

        // ──────────────────────── Primitive helpers ────────────────────────

        private static string ReadTag(BinaryReader br)
        {
            byte[] bytes = br.ReadBytes(4);
            if (bytes.Length < 4) return "";
            return Encoding.ASCII.GetString(bytes);
        }

        private static int ReadBigEndianInt32(BinaryReader br)
        {
            byte[] b = br.ReadBytes(4);
            if (BitConverter.IsLittleEndian)
                Array.Reverse(b);
            return BitConverter.ToInt32(b, 0);
        }

        private static uint ReadBigEndianUInt32(BinaryReader br)
        {
            byte[] b = br.ReadBytes(4);
            if (BitConverter.IsLittleEndian)
                Array.Reverse(b);
            return BitConverter.ToUInt32(b, 0);
        }

        /// <summary>
        /// Reads a null-terminated string with 2-byte alignment padding
        /// (matches HipHopFile.Functions.ReadString).
        /// </summary>
        private static string ReadPaddedString(BinaryReader br)
        {
            var chars = new List<char>();
            byte c;
            while ((c = br.ReadByte()) != 0)
                chars.Add((char)c);

            // Padding: if string length (excluding null) is even, skip one more byte.
            if (chars.Count % 2 == 0)
                br.ReadByte();

            return new string(chars.ToArray());
        }
    }

    /// <summary>
    /// Reads entity placement data (position, rotation, scale, model reference)
    /// from the raw data bytes of entity-type assets (SIMP, PLAT, BUTN, PKUP, VIL, NPC, PLYR, etc.).
    ///
    /// The binary layout depends on the game version:
    ///   - BfBB has a 4-byte padding field after the visibility flags that Scooby/Incredibles don't.
    ///   - All multi-byte fields use platform-native endianness (little for Xbox/PS2, big for GC).
    /// </summary>
    public static class HipEntityReader
    {
        /// <summary>Parsed placement data for one entity asset.</summary>
        public struct EntityPlacement
        {
            public float Yaw, Pitch, Roll;   // radians
            public float PosX, PosY, PosZ;
            public float ScaleX, ScaleY, ScaleZ;
            public uint ModelAssetId;
            public uint AnimationAssetId;
        }

        /// <summary>
        /// Asset type codes that are known to contain entity placement data
        /// (inherit from EntityAsset in Industrial Park).
        /// </summary>
        public static bool IsEntityType(string typeCode)
        {
            switch (typeCode.TrimEnd())
            {
                case "SIMP": // SimpleObject
                case "PLAT": // Platform
                case "BUTN": // Button
                case "PKUP": // Pickup
                case "VIL":  // NPC (Villain)
                case "NPC":  // NPC
                case "PLYR": // Player
                case "BOUL": // Boulder
                case "DSTR": // DestructibleObject
                case "PEND": // Pendulum
                case "HANG": // Hangable
                case "TRIG": // Trigger
                case "TRCK": // Track
                case "EGEN": // ElectricArcGenerator
                case "DUPC": // DuplicatableObject
                case "DVCE": // Device (generic)
                case "VFIG": // Villain (figurine)
                case "EFLY": // EFly
                    return true;
                default:
                    return false;
            }
        }

        /// <summary>
        /// Reads entity placement data from the asset's raw data bytes.
        /// </summary>
        /// <param name="data">Raw asset data bytes.</param>
        /// <param name="game">Game version (affects padding).</param>
        /// <param name="bigEndian">True for GameCube, false for Xbox/PS2.</param>
        public static EntityPlacement Read(byte[] data, HipGame game, bool bigEndian)
        {
            var result = new EntityPlacement();
            if (data == null || data.Length < 48)
                return result;

            // BaseAsset header: 8 bytes (assetID 4 + baseAssetType 1 + linkCount 1 + baseFlags 2)
            // EntityAsset visibility/type/solidity flags: 4 bytes
            int offset = 12;

            // BfBB has a 4-byte padding field here that Scooby and Incredibles don't.
            if (game == HipGame.BFBB)
                offset += 4;

            if (data.Length < offset + 60)
                return result;

            // Surface asset ID
            offset += 4; // skip surface ref

            result.Yaw = ReadFloat(data, offset, bigEndian); offset += 4;
            result.Pitch = ReadFloat(data, offset, bigEndian); offset += 4;
            result.Roll = ReadFloat(data, offset, bigEndian); offset += 4;

            result.PosX = ReadFloat(data, offset, bigEndian); offset += 4;
            result.PosY = ReadFloat(data, offset, bigEndian); offset += 4;
            result.PosZ = ReadFloat(data, offset, bigEndian); offset += 4;

            result.ScaleX = ReadFloat(data, offset, bigEndian); offset += 4;
            result.ScaleY = ReadFloat(data, offset, bigEndian); offset += 4;
            result.ScaleZ = ReadFloat(data, offset, bigEndian); offset += 4;

            // Color (R, G, B, A as floats) + ColorAlphaSpeed
            offset += 5 * 4; // skip color data

            if (data.Length >= offset + 8)
            {
                result.ModelAssetId = ReadUInt32(data, offset, bigEndian); offset += 4;
                result.AnimationAssetId = ReadUInt32(data, offset, bigEndian);
            }

            return result;
        }

        private static float ReadFloat(byte[] data, int offset, bool bigEndian)
        {
            if (bigEndian)
            {
                byte[] tmp = { data[offset + 3], data[offset + 2], data[offset + 1], data[offset] };
                return BitConverter.ToSingle(tmp, 0);
            }
            return BitConverter.ToSingle(data, offset);
        }

        private static uint ReadUInt32(byte[] data, int offset, bool bigEndian)
        {
            if (bigEndian)
            {
                byte[] tmp = { data[offset + 3], data[offset + 2], data[offset + 1], data[offset] };
                return BitConverter.ToUInt32(tmp, 0);
            }
            return BitConverter.ToUInt32(data, offset);
        }
    }
}
