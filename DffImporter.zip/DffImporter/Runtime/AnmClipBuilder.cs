using System.Collections.Generic;
using UnityEngine;

namespace BfbbImport
{
    /// <summary>
    /// Builds a (legacy) Unity AnimationClip from a parsed AnmAsset, driving a set of bone
    /// Transforms in the same order the .anm file expects — which is the same HAnim traversal
    /// order DffParser/ClumpBuilder already use for SkinnedMeshRenderer.bones, so the most
    /// reliable bone array to pass in is exactly that one.
    /// </summary>
    public static class AnmClipBuilder
    {
        public static AnimationClip Build(AnmAsset asset, Transform[] bones, Transform root, bool reverseBoneOrder = false)
        {
            var clip = new AnimationClip { legacy = true };

            int boneCount = Mathf.Min(asset.BoneCount, bones.Length);
            int groupCount = asset.Offsets.Length;

            for (int j = 0; j < boneCount; j++)
            {
                int boneIndex = reverseBoneOrder ? boneCount - 1 - j : j;
                Transform bone = bones[boneIndex];
                if (bone == null) continue;

                string path = GetRelativePath(root, bone);

                var posX = new AnimationCurve();
                var posY = new AnimationCurve();
                var posZ = new AnimationCurve();
                var rotX = new AnimationCurve();
                var rotY = new AnimationCurve();
                var rotZ = new AnimationCurve();
                var rotW = new AnimationCurve();

                for (int i = 0; i < groupCount; i++)
                {
                    ushort keyIdx = asset.Offsets[i][j];
                    if (keyIdx >= asset.Keys.Length) continue;
                    AnmKey key = asset.Keys[keyIdx];

                    float t = (key.TimeIndex >= 0 && key.TimeIndex < asset.Times.Length)
                        ? asset.Times[key.TimeIndex]
                        : 0f;

                    // The MaxScript tool applies Inverse(stored rotation) as the actual bone-local
                    // rotation — mirrored here for a faithful import.
                    Quaternion rot = Quaternion.Inverse(key.Rotation);
                    Vector3 pos = key.Position;

                    posX.AddKey(t, pos.x);
                    posY.AddKey(t, pos.y);
                    posZ.AddKey(t, pos.z);
                    rotX.AddKey(t, rot.x);
                    rotY.AddKey(t, rot.y);
                    rotZ.AddKey(t, rot.z);
                    rotW.AddKey(t, rot.w);
                }

                clip.SetCurve(path, typeof(Transform), "localPosition.x", posX);
                clip.SetCurve(path, typeof(Transform), "localPosition.y", posY);
                clip.SetCurve(path, typeof(Transform), "localPosition.z", posZ);
                clip.SetCurve(path, typeof(Transform), "localRotation.x", rotX);
                clip.SetCurve(path, typeof(Transform), "localRotation.y", rotY);
                clip.SetCurve(path, typeof(Transform), "localRotation.z", rotZ);
                clip.SetCurve(path, typeof(Transform), "localRotation.w", rotW);
            }

            if (asset.Times.Length > 0)
            {
                float duration = asset.Times[asset.Times.Length - 1];
                if (duration > 0f) clip.frameRate = EstimateFrameRate(asset);
            }

            return clip;
        }

        private static float EstimateFrameRate(AnmAsset asset)
        {
            float minDiff = -1f;
            for (int i = 0; i < asset.Times.Length - 1; i++)
            {
                float diff = asset.Times[i + 1] - asset.Times[i];
                if (diff > 0f && (minDiff < 0f || diff < minDiff))
                    minDiff = diff;
            }
            return minDiff > 0f ? 1f / minDiff : 30f;
        }

        private static string GetRelativePath(Transform root, Transform target)
        {
            if (target == root) return "";
            var segments = new List<string>();
            var t = target;
            while (t != null && t != root)
            {
                segments.Add(t.name);
                t = t.parent;
            }
            segments.Reverse();
            return string.Join("/", segments);
        }
    }
}
