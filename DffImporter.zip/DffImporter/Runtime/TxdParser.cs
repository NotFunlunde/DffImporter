using System;
using System.Collections.Generic;
using System.IO;
using UnityEngine;

namespace BfbbImport
{
    /// <summary>
    /// Parses a RenderWare .txd (Texture Dictionary) and produces Unity Texture2D objects.
    ///
    /// Supports the D3D8/D3D9/Xbox-family raster header layout (these three share essentially
    /// the same struct in RW3), covering: 8-bit paletted (32-bit palette), 16-bit (1555/4444/0565),
    /// 24/32-bit RGB(A), and DXT1/DXT3 compressed rasters.
    ///
    /// Xbox-specific handling: the original Xbox build's GPU (NV2A) stores some uncompressed
    /// rasters in a Z-order/Morton "swizzled" tile layout rather than row-major. When the raster
    /// format's swizzle flag is set, the raw bytes are unswizzled before being interpreted as
    /// pixels (see XboxUnswizzle.cs). DXT-compressed blocks are not swizzled this way and are
    /// decoded directly.
    ///
    /// PS2/GameCube-native rasters are NOT supported — those use an entirely different header
    /// (GS register dumps, 4-bit palette indices, etc.) and are skipped with a warning rather
    /// than risking garbage pixels.
    /// </summary>
    public static class TxdParser
    {
        // rwPLATFORMID values that share the generic (non-PS2) raster header layout.
        private const uint PLATFORM_XBOX = 5;
        private const uint PLATFORM_D3D8 = 8;
        private const uint PLATFORM_D3D9 = 9;

        private static bool IsSupportedPlatform(uint id) => id == PLATFORM_XBOX || id == PLATFORM_D3D8 || id == PLATFORM_D3D9;

        public static Dictionary<string, Texture2D> Parse(Stream stream)
        {
            var result = new Dictionary<string, Texture2D>(StringComparer.OrdinalIgnoreCase);
            using var r = new RwReader(stream);

            long chunkEnd = r.ReadChunkHeader(out var header);

            // RWTX assets inside HIP/HOP archives store a single TEXTURE_NATIVE,
            // while standalone .txd files use a TEXTURE_DICTIONARY wrapper.
            if (header.Type == RwChunk.TEXTURE_NATIVE)
            {
                var (name, tex) = ReadTextureNative(r, chunkEnd);
                if (tex != null) result[name] = tex;
                return result;
            }

            if (header.Type != RwChunk.TEXTURE_DICTIONARY)
                throw new InvalidDataException($"Expected TEXTURE_DICTIONARY or TEXTURE_NATIVE chunk, got 0x{header.Type:X4}.");

            long dictEnd = chunkEnd;
            long structEnd = r.ReadChunkHeader(out var sh);
            if (sh.Type != RwChunk.STRUCT) throw new InvalidDataException("Expected STRUCT in TEXTURE_DICTIONARY.");
            ushort numTextures = r.ReadUInt16();
            r.Seek(structEnd);

            for (int i = 0; i < numTextures && r.Position < dictEnd; i++)
            {
                long texEnd = r.ReadChunkHeader(out var th);
                if (th.Type != RwChunk.TEXTURE_NATIVE)
                {
                    r.Seek(texEnd);
                    continue;
                }

                var (name, tex) = ReadTextureNative(r, texEnd);
                if (tex != null) result[name] = tex;
                r.Seek(texEnd);
            }

            return result;
        }

        private static (string name, Texture2D tex) ReadTextureNative(RwReader r, long texEnd)
        {
            long structEnd = r.ReadChunkHeader(out var sh);
            if (sh.Type != RwChunk.STRUCT) throw new InvalidDataException("Expected STRUCT in TEXTURE_NATIVE.");

            uint platformId = r.ReadUInt32();
            ushort filterAddressing = r.ReadUInt16();
            ushort filterAddressing2 = r.ReadUInt16();
            string name = r.ReadFixedString(32);
            string maskName = r.ReadFixedString(32);

            if (!IsSupportedPlatform(platformId))
            {
                Debug.LogWarning($"[DffImporter] Texture '{name}' uses unsupported native platform id {platformId} " +
                                  "(expected Xbox=5, D3D8=8, or D3D9=9 — PS2/GameCube-native rasters use a different " +
                                  "header and aren't handled). Skipping this texture.");
                r.Seek(structEnd);
                return (name, null);
            }

            uint rasterFormat = r.ReadUInt32();
            uint d3dFormatOrFourCC = r.ReadUInt32(); // interpretation depends on rasterFormat
            ushort width = r.ReadUInt16();
            ushort height = r.ReadUInt16();
            byte depth = r.ReadByte();
            byte numLevels = r.ReadByte();
            byte rasterType = r.ReadByte();
            byte compression = r.ReadByte(); // 0 = none, otherwise FOURCC-style flag (DXT)

            Texture2D tex = null;
            try
            {
                tex = DecodeRaster(r, width, height, depth, numLevels, rasterFormat, compression, platformId, name, structEnd);
            }
            catch (Exception ex)
            {
                Debug.LogWarning($"[DffImporter] Failed to decode texture '{name}': {ex.Message}");
            }

            r.Seek(structEnd);
            return (name, tex);
        }

        // RW raster format flags
        private const uint FORMAT_MASK = 0x0F00;
        private const uint FMT_1555 = 0x0100;
        private const uint FMT_565 = 0x0200;
        private const uint FMT_4444 = 0x0300;
        private const uint FMT_8888 = 0x0500;
        private const uint FMT_888 = 0x0600;
        private const uint FMT_PAL8 = 0x2000;     // 8-bit paletted flag
        private const uint RASTER_SWIZZLED = 0x10000; // Z-order/Morton tiled layout (Xbox/NV2A, occasionally PS2)

        private static Texture2D DecodeRaster(RwReader r, int width, int height, int depth, int numLevels,
            uint rasterFormat, byte compression, uint platformId, string name, long structEnd)
        {
            bool isPaletted8 = (rasterFormat & FMT_PAL8) != 0 && depth == 8;
            bool isSwizzled = (rasterFormat & RASTER_SWIZZLED) != 0;
            Color32[] palette = null;

            // Xbox (platform 5) stores a totalMipMapDataSize int32 BEFORE the palette,
            // while D3D8 (platform 8) stores per-mip size prefixes AFTER the palette.
            int xboxTotalMipSize = 0;
            if (platformId == PLATFORM_XBOX)
                xboxTotalMipSize = r.ReadInt32();

            if (isPaletted8)
            {
                int palCount = 256;
                palette = new Color32[palCount];
                for (int p = 0; p < palCount; p++)
                {
                    byte b0 = r.ReadByte(), b1 = r.ReadByte(), b2 = r.ReadByte(), b3 = r.ReadByte();
                    // Xbox/D3D stores palette in BGRA byte order; other platforms use RGBA.
                    if (platformId == PLATFORM_XBOX || platformId == PLATFORM_D3D8 || platformId == PLATFORM_D3D9)
                        palette[p] = new Color32(b2, b1, b0, b3); // BGRA → Color32(R, G, B, A)
                    else
                        palette[p] = new Color32(b0, b1, b2, b3); // RGBA
                }
            }

            // Read pixel data. Xbox has all mip data concatenated without per-level
            // size prefixes. D3D8/D3D9 prefix each mip level with its own size int32.
            int dataSize;
            if (platformId == PLATFORM_XBOX)
            {
                dataSize = xboxTotalMipSize;
            }
            else
            {
                dataSize = r.ReadInt32();
            }
            byte[] allMipData = r.ReadBytes(dataSize);

            var pixels = new Color32[width * height];
            int dxtType = DetectDxtCompression(compression, width, height, dataSize, numLevels);

            byte[] data;
            if (dxtType == 1 || dxtType == 3)
            {
                int blocksWide = Mathf.Max(1, (width + 3) / 4);
                int blocksHigh = Mathf.Max(1, (height + 3) / 4);
                int blockBytes = dxtType == 1 ? 8 : 16;
                int level0Size = blocksWide * blocksHigh * blockBytes;

                if (allMipData.Length < level0Size)
                {
                    LogSizeMismatch(name, dxtType == 1 ? "DXT1" : "DXT3", level0Size, allMipData.Length, width, height);
                    return FlatFallback(width, height, name);
                }
                data = new byte[level0Size];
                Array.Copy(allMipData, data, level0Size);
            }
            else
            {
                int bytesPerPixel = isPaletted8 ? 1 : Mathf.Max(depth / 8, 1);
                int level0Size = width * height * bytesPerPixel;

                if (allMipData.Length < level0Size)
                {
                    LogSizeMismatch(name, isPaletted8 ? "8-bit paletted" : $"uncompressed depth={depth}",
                                     level0Size, allMipData.Length, width, height);
                    return FlatFallback(width, height, name);
                }
                data = new byte[level0Size];
                Array.Copy(allMipData, data, level0Size);
            }

            if (dxtType == 1)
            {
                DxtDecoder.DecompressDxt1(data, width, height, pixels);
            }
            else if (dxtType == 3)
            {
                DxtDecoder.DecompressDxt3(data, width, height, pixels);
            }
            else
            {
                // Uncompressed: unswizzle Xbox Z-order tiling. Xbox (platform 5) ALWAYS stores
                // uncompressed rasters in Morton/Z-order layout regardless of the 0x10000 flag.
                // BfBB in particular never sets the flag but the data IS swizzled.
                if (isSwizzled || platformId == PLATFORM_XBOX)
                {
                    int bpp = isPaletted8 ? 1 : depth / 8;
                    try
                    {
                        data = XboxUnswizzle.Unswizzle(data, width, height, bpp);
                    }
                    catch (Exception ex)
                    {
                        Debug.LogWarning($"[DffImporter] Unswizzle failed for '{name}' ({width}x{height}, {bpp}bpp): {ex.Message}. " +
                                          "Texture may appear scrambled.");
                    }
                }

                if (isPaletted8)
                {
                    if (data.Length < width * height)
                    {
                        LogSizeMismatch(name, "8-bit paletted", width * height, data.Length, width, height);
                        return FlatFallback(width, height, name);
                    }
                    for (int i = 0; i < width * height; i++)
                        pixels[i] = palette[data[i]];
                }
                else
                {
                    int bytesPerPixel = depth / 8;
                    int expected = width * height * Mathf.Max(bytesPerPixel, 1);
                    if (bytesPerPixel <= 0 || data.Length < expected)
                    {
                        LogSizeMismatch(name, $"uncompressed depth={depth}", expected, data.Length, width, height);
                        return FlatFallback(width, height, name);
                    }
                    DecodeUncompressed(data, width, height, depth, rasterFormat, pixels);
                }
            }

            FlipVertical(pixels, width, height);

            var tex = new Texture2D(width, height, TextureFormat.RGBA32, true) { name = name };
            tex.alphaIsTransparency = HasTransparentPixels(pixels);
            tex.SetPixels32(pixels);
            tex.Apply(true);
            return tex;
        }

        private static bool HasTransparentPixels(Color32[] pixels)
        {
            for (int i = 0; i < pixels.Length; i++)
                if (pixels[i].a < 255)
                    return true;
            return false;
        }

        private static void FlipVertical(Color32[] pixels, int width, int height)
        {
            for (int y = 0; y < height / 2; y++)
            {
                int topRow = y * width;
                int botRow = (height - 1 - y) * width;
                for (int x = 0; x < width; x++)
                {
                    var tmp = pixels[topRow + x];
                    pixels[topRow + x] = pixels[botRow + x];
                    pixels[botRow + x] = tmp;
                }
            }
        }

        private static void LogSizeMismatch(string name, string formatLabel, int expectedBytes, int actualBytes, int width, int height)
        {
            Debug.LogWarning($"[DffImporter] Texture '{name}' ({width}x{height}, detected as {formatLabel}) has " +
                              $"{actualBytes} bytes of pixel data but {expectedBytes} were expected for that format/size. " +
                              "This usually means the raster uses a format/layout this importer doesn't recognize yet — " +
                              "using a flat placeholder texture instead of crashing. Please report this if you can, " +
                              "ideally with the texture name and source file, so the format can be added.");
        }

        private static Texture2D FlatFallback(int width, int height, string name)
        {
            var tex = new Texture2D(Mathf.Max(width, 1), Mathf.Max(height, 1), TextureFormat.RGBA32, false) { name = name };
            var fill = new Color32(160, 160, 160, 255);
            var pixels = new Color32[tex.width * tex.height];
            for (int i = 0; i < pixels.Length; i++) pixels[i] = fill;
            tex.SetPixels32(pixels);
            tex.Apply(false);
            return tex;
        }

        /// <summary>
        /// The raster header's last byte means different things across RW versions:
        /// - Legacy (GTA3/VC-era): a plain compression type code — 1 = DXT1, 3 = DXT3.
        /// - Later (SA-era, also used by BfBB): a BITFIELD — bit0=alpha, bit1=cubeTexture,
        ///   bit2=autoMipMaps, bit3=compressed (just a boolean, doesn't say which DXT variant).
        /// When the bitfield form's "compressed" bit is set but doesn't match a legacy code, we
        /// disambiguate DXT1 vs DXT3 by comparing dataSize against the sum of every mip level's
        /// byte count for each candidate format — the actual file stores the WHOLE mip chain
        /// concatenated as one blob, not just level 0, so the comparison has to account for that.
        /// Returns 0 (uncompressed), 1 (DXT1), or 3 (DXT3).
        /// </summary>
        private static int DetectDxtCompression(byte compressionByte, int width, int height, int dataSize, int numLevels)
        {
            if (compressionByte == 1) return 1;
            if (compressionByte == 3) return 3;

            int pixelCount = width * height;
            if (pixelCount <= 0) return 0;

            int dxt1Total = MipChainSum(width, height, numLevels, 8);
            int dxt3Total = MipChainSum(width, height, numLevels, 16);

            if (dataSize == dxt1Total) return 1;
            if (dataSize == dxt3Total) return 3;

            const byte SA_COMPRESSED_BIT = 0x08;
            if ((compressionByte & SA_COMPRESSED_BIT) != 0)
            {
                // Bitfield says "compressed" but the exact byte count didn't match either total
                // exactly (e.g. numLevels itself might be slightly off) — pick whichever total is
                // closer rather than giving up, since we still need *a* level-0 size to slice out.
                return Mathf.Abs(dataSize - dxt1Total) <= Mathf.Abs(dataSize - dxt3Total) ? 1 : 3;
            }

            return 0; // uncompressed — dataSize doesn't match any known compressed layout
        }

        private static int MipChainSum(int width, int height, int numLevels, int blockBytes)
        {
            int total = 0;
            int w = width, h = height;
            int levels = Mathf.Max(numLevels, 1);
            for (int i = 0; i < levels; i++)
            {
                int blocksWide = Mathf.Max(1, (w + 3) / 4);
                int blocksHigh = Mathf.Max(1, (h + 3) / 4);
                total += blocksWide * blocksHigh * blockBytes;
                w = Mathf.Max(1, w / 2);
                h = Mathf.Max(1, h / 2);
            }
            return total;
        }

        private static void DecodeUncompressed(byte[] data, int width, int height, int depth, uint rasterFormat, Color32[] outPixels)
        {
            int n = width * height;
            uint baseFmt = rasterFormat & FORMAT_MASK;

            if (depth == 32)
            {
                for (int i = 0; i < n; i++)
                {
                    int o = i * 4;
                    byte b = data[o + 0], g2 = data[o + 1], rr = data[o + 2], a = data[o + 3]; // stored BGRA
                    outPixels[i] = new Color32(rr, g2, b, a);
                }
            }
            else if (depth == 24)
            {
                for (int i = 0; i < n; i++)
                {
                    int o = i * 3;
                    byte b = data[o + 0], g2 = data[o + 1], rr = data[o + 2];
                    outPixels[i] = new Color32(rr, g2, b, 255);
                }
            }
            else if (depth == 16)
            {
                for (int i = 0; i < n; i++)
                {
                    ushort px = (ushort)(data[i * 2] | (data[i * 2 + 1] << 8));
                    outPixels[i] = baseFmt == FMT_4444 ? Unpack4444(px)
                                   : baseFmt == FMT_565 ? Unpack565(px)
                                   : Unpack1555(px);
                }
            }
            else
            {
                throw new NotSupportedException($"Unsupported raster bit depth {depth} for uncompressed decode.");
            }
        }

        private static Color32 Unpack1555(ushort p)
        {
            byte a = (byte)(((p >> 15) & 0x1) * 255);
            byte r = (byte)(((p >> 10) & 0x1F) * 255 / 31);
            byte g = (byte)(((p >> 5) & 0x1F) * 255 / 31);
            byte b = (byte)((p & 0x1F) * 255 / 31);
            return new Color32(r, g, b, a);
        }

        private static Color32 Unpack565(ushort p)
        {
            byte r = (byte)(((p >> 11) & 0x1F) * 255 / 31);
            byte g = (byte)(((p >> 5) & 0x3F) * 255 / 63);
            byte b = (byte)((p & 0x1F) * 255 / 31);
            return new Color32(r, g, b, 255);
        }

        private static Color32 Unpack4444(ushort p)
        {
            byte a = (byte)(((p >> 12) & 0xF) * 255 / 15);
            byte r = (byte)(((p >> 8) & 0xF) * 255 / 15);
            byte g = (byte)(((p >> 4) & 0xF) * 255 / 15);
            byte b = (byte)((p & 0xF) * 255 / 15);
            return new Color32(r, g, b, a);
        }
    }
}
