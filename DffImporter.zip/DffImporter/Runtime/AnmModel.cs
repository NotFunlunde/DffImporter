using UnityEngine;

namespace BfbbImport
{
    public class AnmKey
    {
        public int TimeIndex;
        public Quaternion Rotation; // raw value from the file; use directly as localRotation in Unity
        public Vector3 Position;
    }

    public class AnmAsset
    {
        public int Flags;
        public int BoneCount;
        public Vector3 Scale; // per-axis multiplier for decoding int16 positions
        public AnmKey[] Keys;
        public float[] Times; // seconds; last entry is the overall clip duration marker
        public ushort[][] Offsets; // [timeCount-1][boneCount] -> index into Keys
    }
}
