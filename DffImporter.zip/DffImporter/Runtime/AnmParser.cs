using System;
using System.IO;
using UnityEngine;

namespace BfbbImport
{
    /// <summary>
    /// Parses Heavy Iron Studios' "SKB1" animation format (.anm files, used by BfBB and other
    /// EvilEngine-era games). This is NOT a RenderWare chunk format — it's a separate, compact
    /// compressed-keyframe format specific to these games.
    ///
    /// Ported directly from the community's BFBBAnimTools.ms (3ds Max MaxScript, by Seil and
    /// igorseabra4), which is the authoritative reference implementation for this format.
    ///
    /// Byte order: PS2/Xbox files are little-endian (magic reads as "SKB1" with no swap needed).
    /// GameCube files are stored byte-swapped (magic reads as "1BKS" raw, requiring a swap to
    /// interpret as "SKB1") — this is detected automatically and handled transparently.
    /// </summary>
    public static class AnmParser
    {
        private const int MAGIC_NO_SWAP = 0x534B4231; // "1BKS" as a little-endian read of "SKB1" bytes
        private const int MAGIC_SWAPPED = 0x31424B53; // "SKB1" as a little-endian read — i.e. native PS2/Xbox files

        public static AnmAsset Parse(Stream stream)
        {
            using var br = new BinaryReader(stream);

            int rawMagic = br.ReadInt32();
            bool swap;
            if (rawMagic == MAGIC_SWAPPED) swap = false;       // PS2/Xbox: already little-endian, no swap
            else if (rawMagic == MAGIC_NO_SWAP) swap = true;   // GameCube: big-endian, needs swapping
            else throw new InvalidDataException($"Not a valid ANIM file (bad magic 0x{rawMagic:X8}).");

            var asset = new AnmAsset
            {
                Flags = ReadInt32(br, swap),
            };

            int boneCount = ReadInt16(br, swap);
            int timeCount = ReadInt16(br, swap);
            int keyCount = ReadInt32(br, swap);

            asset.BoneCount = boneCount;
            asset.Scale = new Vector3(ReadFloat(br, swap), ReadFloat(br, swap), ReadFloat(br, swap));

            asset.Keys = new AnmKey[keyCount];
            for (int i = 0; i < keyCount; i++)
            {
                var key = new AnmKey { TimeIndex = ReadInt16(br, swap) };

                float rx = ReadInt16(br, swap) / 32767.0f;
                float ry = ReadInt16(br, swap) / 32767.0f;
                float rz = ReadInt16(br, swap) / 32767.0f;
                float rw = ReadInt16(br, swap) / 32767.0f;
                key.Rotation = new Quaternion(rx, ry, rz, rw);

                float px = ReadInt16(br, swap) * asset.Scale.x;
                float py = ReadInt16(br, swap) * asset.Scale.y;
                float pz = ReadInt16(br, swap) * asset.Scale.z;
                key.Position = new Vector3(px, py, pz);

                asset.Keys[i] = key;
            }

            asset.Times = new float[timeCount];
            for (int i = 0; i < timeCount; i++)
                asset.Times[i] = ReadFloat(br, swap);

            int offsetGroups = Mathf.Max(0, timeCount - 1);
            asset.Offsets = new ushort[offsetGroups][];
            for (int i = 0; i < offsetGroups; i++)
            {
                var group = new ushort[boneCount];
                for (int j = 0; j < boneCount; j++)
                    group[j] = (ushort)ReadInt16(br, swap, unsignedRead: true);
                asset.Offsets[i] = group;
            }

            return asset;
        }

        // --- swap-aware primitive reads, mirroring _ReadInt/_ReadShort/_ReadFloat in the .ms file ---

        private static int ReadInt32(BinaryReader br, bool swap)
        {
            int x = br.ReadInt32();
            return swap ? SwapInt(x) : x;
        }

        private static int ReadInt16(BinaryReader br, bool swap, bool unsignedRead = false)
        {
            if (unsignedRead)
            {
                ushort u = br.ReadUInt16();
                if (!swap) return u;
                return SwapShort(u) & 0xFFFF;
            }
            short s = br.ReadInt16();
            return swap ? SwapShort(s) : s;
        }

        private static float ReadFloat(BinaryReader br, bool swap)
        {
            int bits = ReadInt32(br, swap);
            return BitConverter.Int32BitsToSingle(bits);
        }

        private static int SwapInt(int x)
        {
            uint u = (uint)x;
            u = (u >> 24) | ((u >> 8) & 0xFF00) | ((u << 8) & 0xFF0000) | (u << 24);
            return (int)u;
        }

        private static int SwapShort(int x)
        {
            ushort u = (ushort)x;
            u = (ushort)((u >> 8) | (u << 8));
            return (short)u; // sign-extend, matching the .ms file's SwapShort behavior
        }
    }
}
