using System.IO;
using UnityEditor;
#if UNITY_2020_2_OR_NEWER
using UnityEditor.AssetImporters;
#else
using UnityEditor.Experimental.AssetImporters;
#endif
using UnityEngine;

namespace BfbbImport.Editor
{
    /// <summary>
    /// Makes .txd files (RenderWare Texture Dictionary) importable as native Unity assets.
    /// Drop a .txd into the Project window and each raster inside becomes a Texture2D sub-asset.
    ///
    /// The main asset is a placeholder GameObject (required by ScriptedImporter); the useful
    /// content is the Texture2D sub-assets, which can be dragged onto materials or referenced
    /// from scripts like any other texture.
    /// </summary>
    [ScriptedImporter(1, "txd")]
    public class TxdImporter : ScriptedImporter
    {
        public override void OnImportAsset(AssetImportContext ctx)
        {
            Debug.Log($"[TxdImporter] Importing '{ctx.assetPath}'");

            System.Collections.Generic.Dictionary<string, Texture2D> textures;
            try
            {
                using var fs = File.OpenRead(ctx.assetPath);
                textures = TxdParser.Parse(fs);
            }
            catch (System.Exception ex)
            {
                ctx.LogImportError($"Failed to parse TXD '{ctx.assetPath}': {ex.Message}");
                return;
            }

            if (textures.Count == 0)
            {
                ctx.LogImportWarning($"TXD '{ctx.assetPath}' contained no textures.");
                return;
            }

            // If there's exactly one texture, make it the main asset directly.
            // Otherwise, create a container and attach all textures as sub-assets.
            if (textures.Count == 1)
            {
                foreach (var kv in textures)
                {
                    kv.Value.name = kv.Key;
                    ctx.AddObjectToAsset("main_tex", kv.Value);
                    ctx.SetMainObject(kv.Value);
                }
            }
            else
            {
                // Use the first texture as the main object (Unity requires one) and register
                // the rest as sub-assets. All textures are accessible via the asset's sub-objects.
                bool first = true;
                foreach (var kv in textures)
                {
                    kv.Value.name = kv.Key;
                    ctx.AddObjectToAsset(kv.Key, kv.Value);
                    if (first)
                    {
                        ctx.SetMainObject(kv.Value);
                        first = false;
                    }
                }
            }

            Debug.Log($"[TxdImporter] Imported {textures.Count} texture(s) from '{ctx.assetPath}'.");
        }
    }
}
