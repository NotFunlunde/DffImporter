using System.Collections.Generic;
using System.Linq;
using UnityEditor;
using UnityEngine;

namespace BfbbImport.Editor
{
    /// <summary>
    /// Assigns a user-chosen prefab or model to one or more placement GameObjects that were
    /// created by the HIP/HOP importer. Select the placements from the scene hierarchy
    /// (or search/filter by name), drag in a prefab, and click Assign — the prefab is
    /// instantiated at each placement's position/rotation/scale.
    ///
    /// Usage: Tools > BfBB DFF > Assign Assets to HIP Placements...
    /// </summary>
    public class HipAssetAssigner : EditorWindow
    {
        private GameObject prefabToAssign;
        private Texture2D textureToApply;
        private Transform hipRoot;
        private string searchFilter = "";
        private Vector2 scrollPos;
        private HashSet<Transform> selectedPlacements = new HashSet<Transform>();
        private bool replaceExisting = true;

        // Cached filtered list, rebuilt when filter or root changes.
        private Transform[] filteredChildren;
        private string lastFilter;
        private Transform lastRoot;

        [MenuItem("Tools/BfBB DFF/Assign Assets to HIP Placements...")]
        private static void Open()
        {
            GetWindow<HipAssetAssigner>("HIP Asset Assigner");
        }

        private void OnGUI()
        {
            EditorGUILayout.LabelField("Assign Assets to HIP Placements", EditorStyles.boldLabel);
            EditorGUILayout.Space();

            // ── Prefab / model field ──
            prefabToAssign = (GameObject)EditorGUILayout.ObjectField(
                new GUIContent("Model / Prefab", "The asset to instantiate at each selected placement."),
                prefabToAssign, typeof(GameObject), false);

            // ── Texture field ──
            textureToApply = (Texture2D)EditorGUILayout.ObjectField(
                new GUIContent("Texture", "A texture to apply to all renderers on the selected objects."),
                textureToApply, typeof(Texture2D), false);

            // ── HIP root (the parent created by the importer) ──
            hipRoot = (Transform)EditorGUILayout.ObjectField(
                new GUIContent("HIP Root", "The root GameObject created by the HIP/HOP importer (e.g. the level name)."),
                hipRoot, typeof(Transform), true);

            replaceExisting = EditorGUILayout.Toggle(
                new GUIContent("Replace Existing Children",
                    "If checked, any existing children of the placement are removed before assigning the new model."),
                replaceExisting);

            EditorGUILayout.Space();

            if (hipRoot == null)
            {
                EditorGUILayout.HelpBox(
                    "Drag the root of an imported HIP/HOP hierarchy from the scene into the " +
                    "\"HIP Root\" field above. Then search for placements by name and assign your model.",
                    MessageType.Info);
                return;
            }

            // ── Search / filter ──
            EditorGUILayout.BeginHorizontal();
            EditorGUILayout.LabelField("Search", GUILayout.Width(50));
            searchFilter = EditorGUILayout.TextField(searchFilter);
            if (GUILayout.Button("Select All Visible", GUILayout.Width(120)))
                SelectAllVisible();
            if (GUILayout.Button("Deselect All", GUILayout.Width(90)))
                selectedPlacements.Clear();
            EditorGUILayout.EndHorizontal();

            RebuildFilteredList();

            // ── Selection count ──
            EditorGUILayout.LabelField($"{selectedPlacements.Count} selected / {filteredChildren.Length} shown / {hipRoot.childCount} total");

            // ── Scrollable placement list ──
            scrollPos = EditorGUILayout.BeginScrollView(scrollPos, GUILayout.ExpandHeight(true));

            for (int i = 0; i < filteredChildren.Length; i++)
            {
                var child = filteredChildren[i];
                if (child == null) continue;

                EditorGUILayout.BeginHorizontal();

                bool wasSelected = selectedPlacements.Contains(child);
                bool nowSelected = EditorGUILayout.Toggle(wasSelected, GUILayout.Width(20));
                if (nowSelected && !wasSelected) selectedPlacements.Add(child);
                else if (!nowSelected && wasSelected) selectedPlacements.Remove(child);

                // Clicking the label selects the object in the hierarchy for inspection.
                if (GUILayout.Button(child.name, EditorStyles.label))
                {
                    Selection.activeGameObject = child.gameObject;
                    EditorGUIUtility.PingObject(child.gameObject);
                }

                // Show child count indicator (has model vs empty marker).
                int childCount = child.childCount;
                if (childCount > 0)
                    EditorGUILayout.LabelField($"({childCount} children)", GUILayout.Width(90));
                else
                    EditorGUILayout.LabelField("(empty)", GUILayout.Width(90));

                EditorGUILayout.EndHorizontal();
            }

            EditorGUILayout.EndScrollView();

            // ── Assign button ──
            EditorGUILayout.Space();
            using (new EditorGUI.DisabledScope(prefabToAssign == null || selectedPlacements.Count == 0))
            {
                if (GUILayout.Button($"Assign Model to {selectedPlacements.Count} Placement(s)", GUILayout.Height(30)))
                    DoAssign();
            }

            // ── Apply Texture button ──
            using (new EditorGUI.DisabledScope(textureToApply == null || selectedPlacements.Count == 0))
            {
                if (GUILayout.Button($"Apply Texture to {selectedPlacements.Count} Placement(s)", GUILayout.Height(30)))
                    DoApplyTexture();
            }
        }

        private void RebuildFilteredList()
        {
            if (filteredChildren != null && lastRoot == hipRoot && lastFilter == searchFilter)
                return;

            lastRoot = hipRoot;
            lastFilter = searchFilter;

            var children = new List<Transform>();
            for (int i = 0; i < hipRoot.childCount; i++)
                children.Add(hipRoot.GetChild(i));

            if (!string.IsNullOrEmpty(searchFilter))
            {
                string upper = searchFilter.ToUpperInvariant();
                children = children.Where(c => c.name.ToUpperInvariant().Contains(upper)).ToList();
            }

            filteredChildren = children.ToArray();
        }

        private void SelectAllVisible()
        {
            RebuildFilteredList();
            foreach (var child in filteredChildren)
                if (child != null)
                    selectedPlacements.Add(child);
        }

        private void DoApplyTexture()
        {
            selectedPlacements.RemoveWhere(t => t == null);
            if (selectedPlacements.Count == 0) return;

            Undo.SetCurrentGroupName("Apply Texture to HIP Placements");
            int undoGroup = Undo.GetCurrentGroup();
            int rendererCount = 0;

            foreach (var placement in selectedPlacements)
            {
                if (placement == null) continue;

                var renderers = placement.GetComponentsInChildren<Renderer>(true);
                foreach (var renderer in renderers)
                {
                    foreach (var mat in renderer.sharedMaterials)
                    {
                        if (mat == null) continue;
                        Undo.RecordObject(mat, "Apply Texture");
                        if (mat.HasProperty("_BaseMap"))
                            mat.SetTexture("_BaseMap", textureToApply);
                        else if (mat.HasProperty("_MainTex"))
                            mat.SetTexture("_MainTex", textureToApply);
                    }
                    rendererCount++;
                }
            }

            Undo.CollapseUndoOperations(undoGroup);

            Debug.Log($"[HipAssetAssigner] Applied texture '{textureToApply.name}' to {rendererCount} renderer(s) across {selectedPlacements.Count} placement(s).");
            EditorUtility.DisplayDialog("HIP Asset Assigner",
                $"Applied texture '{textureToApply.name}' to {rendererCount} renderer(s) across {selectedPlacements.Count} placement(s).", "OK");
        }

        private void DoAssign()
        {
            // Clean out any selections that have been destroyed since they were selected.
            selectedPlacements.RemoveWhere(t => t == null);

            if (selectedPlacements.Count == 0) return;

            Undo.SetCurrentGroupName("Assign HIP Assets");
            int undoGroup = Undo.GetCurrentGroup();

            bool isPrefab = PrefabUtility.GetPrefabAssetType(prefabToAssign) != PrefabAssetType.NotAPrefab;
            int count = 0;

            foreach (var placement in selectedPlacements)
            {
                if (placement == null) continue;

                // Optionally remove existing children (previous model assignments).
                if (replaceExisting)
                {
                    for (int c = placement.childCount - 1; c >= 0; c--)
                        Undo.DestroyObjectImmediate(placement.GetChild(c).gameObject);
                }

                GameObject instance;
                if (isPrefab)
                    instance = (GameObject)PrefabUtility.InstantiatePrefab(prefabToAssign);
                else
                    instance = Instantiate(prefabToAssign);

                instance.name = prefabToAssign.name;
                Undo.RegisterCreatedObjectUndo(instance, "Assign HIP Asset");
                instance.transform.SetParent(placement, false);
                instance.transform.localPosition = Vector3.zero;
                instance.transform.localRotation = Quaternion.identity;

                instance.transform.localScale = Vector3.one;

                count++;
            }

            Undo.CollapseUndoOperations(undoGroup);

            Debug.Log($"[HipAssetAssigner] Assigned '{prefabToAssign.name}' to {count} placement(s).");
            EditorUtility.DisplayDialog("HIP Asset Assigner",
                $"Assigned '{prefabToAssign.name}' to {count} placement(s).", "OK");

            // Force list to rebuild so child-count labels update.
            lastFilter = null;

            selectedPlacements.Clear();
        }
    }
}
