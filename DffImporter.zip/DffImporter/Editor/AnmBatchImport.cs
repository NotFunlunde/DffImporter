using System.IO;
using System.Linq;
using UnityEditor;
using UnityEditor.Animations;
using UnityEngine;

namespace BfbbImport.Editor
{
    /// <summary>
    /// Batch-imports a folder of .anm files into Unity AnimationClips for a single target model.
    /// Creates one AnimatorController containing all imported clips as states.
    ///
    /// Usage: Tools/BfBB DFF/Batch Import ANM Animations...
    ///   1. Pick a folder containing .anm files.
    ///   2. Drag the root of your imported .dff model into the "Target Model" field.
    ///   3. Choose an output folder inside Assets.
    ///   4. Click Import All.
    /// </summary>
    public class AnmBatchImport : EditorWindow
    {
        private string sourceFolder;
        private GameObject targetModel;
        private bool reverseBoneOrder;
        private bool invertRotation;
        private bool loopAnimation = true;

        [MenuItem("Tools/BfBB DFF/Batch Import ANM Animations...")]
        private static void Open()
        {
            GetWindow<AnmBatchImport>("Batch Import ANM");
        }

        private void OnGUI()
        {
            EditorGUILayout.LabelField("BfBB Batch .anm Importer", EditorStyles.boldLabel);
            EditorGUILayout.Space();

            EditorGUILayout.BeginHorizontal();
            EditorGUILayout.LabelField("Source Folder", GUILayout.Width(100));
            EditorGUILayout.LabelField(string.IsNullOrEmpty(sourceFolder) ? "(none selected)" : sourceFolder);
            if (GUILayout.Button("Browse...", GUILayout.Width(80)))
            {
                string picked = EditorUtility.OpenFolderPanel("Select folder containing .anm files", "", "");
                if (!string.IsNullOrEmpty(picked)) sourceFolder = picked;
            }
            EditorGUILayout.EndHorizontal();

            targetModel = (GameObject)EditorGUILayout.ObjectField(
                "Target Model (imported .dff)", targetModel, typeof(GameObject), true);

            reverseBoneOrder = EditorGUILayout.Toggle(
                new GUIContent("Reverse Bone Order", "Matches the same checkbox in BFBBAnimTools.ms."),
                reverseBoneOrder);

            invertRotation = EditorGUILayout.Toggle(
                new GUIContent("Invert Rotation", "Applies Quaternion.Inverse to stored rotations."),
                invertRotation);

            loopAnimation = EditorGUILayout.Toggle(
                new GUIContent("Loop Animations", "Whether all imported clips should loop."),
                loopAnimation);

            EditorGUILayout.Space();

            using (new EditorGUI.DisabledScope(string.IsNullOrEmpty(sourceFolder) || targetModel == null))
            {
                if (GUILayout.Button("Import All", GUILayout.Height(30)))
                    ImportAll();
            }

            EditorGUILayout.HelpBox(
                "All .anm files in the selected folder (and subfolders) will be imported as " +
                "AnimationClips. A single AnimatorController is created containing every clip. " +
                "The target model must have a SkinnedMeshRenderer with bones from the DFF importer.",
                MessageType.Info);
        }

        private void ImportAll()
        {
            var smr = targetModel.GetComponentInChildren<SkinnedMeshRenderer>();
            if (smr == null || smr.bones == null || smr.bones.Length == 0)
            {
                EditorUtility.DisplayDialog("Batch Import ANM",
                    "No SkinnedMeshRenderer with bones found under the target model.", "OK");
                return;
            }

            var anmFiles = Directory.GetFiles(sourceFolder, "*.anm", SearchOption.AllDirectories)
                .OrderBy(f => Path.GetFileNameWithoutExtension(f))
                .ToArray();

            if (anmFiles.Length == 0)
            {
                EditorUtility.DisplayDialog("Batch Import ANM", "No .anm files found in the selected folder.", "OK");
                return;
            }

            string outputFolder = EditorUtility.SaveFolderPanel(
                "Choose output folder inside Assets", Application.dataPath, "Animations");
            if (string.IsNullOrEmpty(outputFolder)) return;

            if (!outputFolder.Replace('\\', '/').StartsWith(Application.dataPath.Replace('\\', '/')))
            {
                EditorUtility.DisplayDialog("Batch Import ANM",
                    "The output folder must be inside this project's Assets folder.", "OK");
                return;
            }

            string assetsRelative = "Assets" + outputFolder.Replace('\\', '/').Substring(Application.dataPath.Replace('\\', '/').Length);
            if (!AssetDatabase.IsValidFolder(assetsRelative))
            {
                Directory.CreateDirectory(outputFolder);
                AssetDatabase.Refresh();
            }

            int imported = 0;
            int failed = 0;
            var clips = new System.Collections.Generic.List<AnimationClip>();

            for (int i = 0; i < anmFiles.Length; i++)
            {
                string anmPath = anmFiles[i];
                string clipName = Path.GetFileNameWithoutExtension(anmPath);

                EditorUtility.DisplayProgressBar("Importing .anm files",
                    $"{clipName} ({i + 1}/{anmFiles.Length})", (float)i / anmFiles.Length);

                AnmAsset asset;
                try
                {
                    using var fs = File.OpenRead(anmPath);
                    asset = AnmParser.Parse(fs);
                }
                catch (System.Exception ex)
                {
                    Debug.LogWarning($"[AnmBatchImport] Failed to parse '{anmPath}': {ex.Message}");
                    failed++;
                    continue;
                }

                AnimationClip clip = AnmClipBuilder.Build(asset, smr.bones, targetModel.transform,
                    reverseBoneOrder, invertRotation);
                clip.name = clipName;

                var clipSettings = AnimationUtility.GetAnimationClipSettings(clip);
                clipSettings.loopTime = loopAnimation;
                AnimationUtility.SetAnimationClipSettings(clip, clipSettings);

                string savePath = $"{assetsRelative}/{clipName}.anim";
                AssetDatabase.CreateAsset(clip, savePath);
                clips.Add(clip);
                imported++;
            }

            EditorUtility.ClearProgressBar();

            if (clips.Count > 0)
            {
                string controllerPath = $"{assetsRelative}/{targetModel.name}_Animations.controller";
                var controller = AnimatorController.CreateAnimatorControllerAtPath(controllerPath);
                foreach (var clip in clips)
                    controller.AddMotion(clip);
                AssetDatabase.SaveAssets();

                var animator = targetModel.GetComponent<Animator>();
                if (animator == null)
                    animator = targetModel.AddComponent<Animator>();
                if (animator.runtimeAnimatorController == null)
                    animator.runtimeAnimatorController = controller;
            }

            AssetDatabase.SaveAssets();
            AssetDatabase.Refresh();

            string msg = $"Imported {imported} animation(s).";
            if (failed > 0) msg += $" {failed} file(s) failed (see console).";
            EditorUtility.DisplayDialog("Batch Import ANM", msg, "OK");
            Debug.Log($"[AnmBatchImport] {msg}");
        }
    }
}
