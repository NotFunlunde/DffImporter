using UnityEditor;
using UnityEngine;
using UnityEngine.Rendering;

namespace BfbbImport.Editor
{
    /// <summary>
    /// One-click scene setup that configures lighting, fog, camera, and materials to match
    /// BfBB's visual style. Access via Tools > BfBB DFF > Setup BfBB Scene Appearance.
    /// </summary>
    public class BfbbSceneSetup : EditorWindow
    {
        private bool applyLighting = true;
        private bool applyFog = true;
        private bool applyCamera = true;
        private bool applyShaderToScene = true;

        private Color ambientColor = new Color(0.5f, 0.6f, 0.67f, 1f); // #809AAA
        private Color sunColor = new Color(1f, 0.957f, 0.878f, 1f); // #FFF4E0
        private float sunIntensity = 1.0f;
        private Vector3 sunRotation = new Vector3(50f, -30f, 0f);

        private Color fogColor = new Color(0.627f, 0.816f, 0.941f, 1f); // #A0D0F0
        private float fogStart = 40f;
        private float fogEnd = 120f;

        private float cameraFov = 60f;

        [MenuItem("Tools/BfBB DFF/Setup BfBB Scene Appearance...")]
        public static void ShowWindow()
        {
            GetWindow<BfbbSceneSetup>("BfBB Scene Setup");
        }

        private void OnGUI()
        {
            EditorGUILayout.LabelField("BfBB Scene Appearance Setup", EditorStyles.boldLabel);
            EditorGUILayout.Space();
            EditorGUILayout.HelpBox(
                "Configures the active scene to approximate BfBB's visual style:\n" +
                "- Flat ambient + warm directional light (no realtime shadows)\n" +
                "- Linear distance fog\n" +
                "- Unlit vertex-color shader on all scene renderers",
                MessageType.Info);
            EditorGUILayout.Space();

            // Lighting section
            applyLighting = EditorGUILayout.BeginToggleGroup("Lighting", applyLighting);
            EditorGUI.indentLevel++;
            ambientColor = EditorGUILayout.ColorField("Ambient Color", ambientColor);
            sunColor = EditorGUILayout.ColorField("Sun Color", sunColor);
            sunIntensity = EditorGUILayout.FloatField("Sun Intensity", sunIntensity);
            sunRotation = EditorGUILayout.Vector3Field("Sun Rotation", sunRotation);
            EditorGUI.indentLevel--;
            EditorGUILayout.EndToggleGroup();

            EditorGUILayout.Space();

            // Fog section
            applyFog = EditorGUILayout.BeginToggleGroup("Fog", applyFog);
            EditorGUI.indentLevel++;
            fogColor = EditorGUILayout.ColorField("Fog Color", fogColor);
            fogStart = EditorGUILayout.FloatField("Fog Start", fogStart);
            fogEnd = EditorGUILayout.FloatField("Fog End", fogEnd);
            EditorGUI.indentLevel--;
            EditorGUILayout.EndToggleGroup();

            EditorGUILayout.Space();

            // Camera section
            applyCamera = EditorGUILayout.BeginToggleGroup("Camera", applyCamera);
            EditorGUI.indentLevel++;
            cameraFov = EditorGUILayout.Slider("Field of View", cameraFov, 30f, 90f);
            EditorGUI.indentLevel--;
            EditorGUILayout.EndToggleGroup();

            EditorGUILayout.Space();

            // Shader section
            applyShaderToScene = EditorGUILayout.BeginToggleGroup("Apply BfBB Shader to Scene", applyShaderToScene);
            EditorGUI.indentLevel++;
            EditorGUILayout.LabelField("Replaces materials on all renderers with BfBB/Unlit Vertex Color");
            EditorGUI.indentLevel--;
            EditorGUILayout.EndToggleGroup();

            EditorGUILayout.Space();
            EditorGUILayout.Space();

            if (GUILayout.Button("Apply Scene Setup", GUILayout.Height(30)))
            {
                ApplySetup();
            }
        }

        private void ApplySetup()
        {
            Undo.SetCurrentGroupName("BfBB Scene Setup");
            int undoGroup = Undo.GetCurrentGroup();

            if (applyLighting)
                SetupLighting();
            if (applyFog)
                SetupFog();
            if (applyCamera)
                SetupCamera();
            if (applyShaderToScene)
                ApplyBfbbShader();

            Undo.CollapseUndoOperations(undoGroup);

            Debug.Log("[BfBB Scene Setup] Scene appearance configured.");
            EditorUtility.DisplayDialog("BfBB Scene Setup",
                "Scene appearance has been configured to match BfBB's visual style.", "OK");
        }

        private void SetupLighting()
        {
            // Set ambient light
            RenderSettings.ambientMode = AmbientMode.Flat;
            RenderSettings.ambientLight = ambientColor;

            // Find or create directional light
            Light sun = null;
            var lights = Object.FindObjectsOfType<Light>();
            foreach (var l in lights)
            {
                if (l.type == LightType.Directional)
                {
                    sun = l;
                    break;
                }
            }

            if (sun == null)
            {
                var sunGo = new GameObject("BfBB Sun");
                Undo.RegisterCreatedObjectUndo(sunGo, "Create Sun");
                sun = sunGo.AddComponent<Light>();
                sun.type = LightType.Directional;
            }
            else
            {
                Undo.RecordObject(sun.transform, "Setup Sun");
                Undo.RecordObject(sun, "Setup Sun");
            }

            sun.color = sunColor;
            sun.intensity = sunIntensity;
            sun.shadows = LightShadows.None;
            sun.transform.eulerAngles = sunRotation;
        }

        private void SetupFog()
        {
            RenderSettings.fog = true;
            RenderSettings.fogMode = FogMode.Linear;
            RenderSettings.fogColor = fogColor;
            RenderSettings.fogStartDistance = fogStart;
            RenderSettings.fogEndDistance = fogEnd;

            // Match skybox/background to fog color for seamless blend
            if (Camera.main != null)
            {
                Undo.RecordObject(Camera.main, "Setup Fog Background");
                Camera.main.backgroundColor = fogColor;
                Camera.main.clearFlags = CameraClearFlags.SolidColor;
            }
        }

        private void SetupCamera()
        {
            var cam = Camera.main;
            if (cam == null)
            {
                Debug.LogWarning("[BfBB Scene Setup] No main camera found. Skipping camera setup.");
                return;
            }

            Undo.RecordObject(cam, "Setup Camera");
            cam.fieldOfView = cameraFov;
            cam.farClipPlane = fogEnd + 20f;
        }

        private void ApplyBfbbShader()
        {
            var shader = Shader.Find("BfBB/Unlit Vertex Color");
            if (shader == null)
            {
                Debug.LogError("[BfBB Scene Setup] Could not find 'BfBB/Unlit Vertex Color' shader. " +
                               "Make sure the shader file is in your project.");
                EditorUtility.DisplayDialog("BfBB Scene Setup",
                    "Could not find 'BfBB/Unlit Vertex Color' shader.\n\n" +
                    "Make sure the DffImporter package (with Runtime/Shaders/BfbbUnlit.shader) " +
                    "is imported into your project.", "OK");
                return;
            }

            int count = 0;
            var renderers = Object.FindObjectsOfType<Renderer>();
            foreach (var renderer in renderers)
            {
                var materials = renderer.sharedMaterials;
                for (int i = 0; i < materials.Length; i++)
                {
                    var mat = materials[i];
                    if (mat == null) continue;
                    if (mat.shader == shader) continue;

                    Undo.RecordObject(mat, "Apply BfBB Shader");

                    // Preserve existing texture
                    Texture mainTex = null;
                    if (mat.HasProperty("_BaseMap"))
                        mainTex = mat.GetTexture("_BaseMap");
                    else if (mat.HasProperty("_MainTex"))
                        mainTex = mat.GetTexture("_MainTex");

                    mat.shader = shader;

                    if (mainTex != null)
                        mat.SetTexture("_MainTex", mainTex);

                    // Default to double-sided (Cull Off = 0)
                    mat.SetFloat("_Cull", 0f);

                    count++;
                }
            }

            Debug.Log($"[BfBB Scene Setup] Applied BfBB shader to {count} material(s).");
        }
    }
}
