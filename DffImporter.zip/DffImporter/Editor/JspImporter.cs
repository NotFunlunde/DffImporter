using System.Collections.Generic;
using System.IO;
using UnityEditor;
#if UNITY_2020_2_OR_NEWER
using UnityEditor.AssetImporters;
#else
using UnityEditor.Experimental.AssetImporters;
#endif
using UnityEngine;

namespace BfbbImport.Editor
{
    /// <summary>
    /// Makes .jsp files (RenderWare World/BSP level geometry) importable as native Unity assets.
    /// Drop a .jsp file into the Project window and it becomes a prefab with one child mesh
    /// per BSP sector, textured from adjacent .txd files.
    /// </summary>
    [ScriptedImporter(1, "jsp")]
    public class JspImporter : ScriptedImporter
    {
        [Tooltip("Shader used for generated materials. Defaults to URP/Lit if available, else Standard.")]
        public Shader shaderOverride;

        [Tooltip("Uniform scale applied to the imported level geometry.")]
        public float importScale = 1f;

        public override void OnImportAsset(AssetImportContext ctx)
        {
            Debug.Log($"[JspImporter] OnImportAsset running for '{ctx.assetPath}'");

            RwWorld world;
            try
            {
                using var fs = File.OpenRead(ctx.assetPath);
                world = JspParser.Parse(fs);
            }
            catch (System.Exception ex)
            {
                ctx.LogImportError($"Failed to parse JSP '{ctx.assetPath}': {ex.Message}");
                return;
            }

            if (world.Sectors.Count == 0)
            {
                ctx.LogImportWarning($"JSP '{ctx.assetPath}' contains no geometry sectors.");
            }

            var textures = LoadAdjacentTextures(ctx.assetPath, ctx);

            Shader shader = shaderOverride;
            if (shader == null)
            {
                string[] candidates =
                {
                    "Universal Render Pipeline/Lit",
                    "HDRP/Lit",
                    "Standard",
                    "Legacy Shaders/Diffuse",
                    "Mobile/Diffuse",
                    "Sprites/Default",
                };
                foreach (var name in candidates)
                {
                    shader = Shader.Find(name);
                    if (shader != null) break;
                }
            }

            if (shader == null)
            {
                ctx.LogImportError("No suitable shader found. Assign 'shaderOverride' in the Inspector.");
                return;
            }

            string rootName = Path.GetFileNameWithoutExtension(ctx.assetPath);
            var root = new GameObject(rootName);
            root.transform.localScale = new Vector3(-1f, 1f, 1f) * importScale;

            var seenMeshes = new HashSet<Mesh>();
            var seenMats = new HashSet<Material>();

            for (int i = 0; i < world.Sectors.Count; i++)
            {
                var sector = world.Sectors[i];
                var mesh = ClumpBuilder.BuildMesh(sector);
                mesh.name = $"{rootName}_sector{i}";

                var materials = ClumpBuilder.BuildMaterials(sector, textures, shader);

                var sectorGo = new GameObject($"Sector_{i}");
                sectorGo.transform.SetParent(root.transform, false);

                var mf = sectorGo.AddComponent<MeshFilter>();
                mf.sharedMesh = mesh;
                var mr = sectorGo.AddComponent<MeshRenderer>();
                mr.sharedMaterials = materials;

                if (seenMeshes.Add(mesh))
                    ctx.AddObjectToAsset($"mesh_{i}", mesh);

                foreach (var mat in materials)
                {
                    if (mat != null && seenMats.Add(mat))
                        ctx.AddObjectToAsset($"mat_{mat.name}_{mat.GetInstanceID()}", mat);
                }

                ctx.AddObjectToAsset($"sector_{i}", sectorGo);
            }

            ctx.AddObjectToAsset("root", root);
            ctx.SetMainObject(root);

            foreach (var kv in textures)
            {
                if (kv.Value != null)
                    ctx.AddObjectToAsset("tex_" + kv.Key, kv.Value);
            }
        }

        private static Dictionary<string, Texture2D> LoadAdjacentTextures(string assetPath, AssetImportContext ctx)
        {
            var combined = new Dictionary<string, Texture2D>(System.StringComparer.OrdinalIgnoreCase);
            string dir = Path.GetDirectoryName(assetPath);
            string baseName = Path.GetFileNameWithoutExtension(assetPath);

            var candidates = new List<string>();
            string sameNamed = Path.Combine(dir, baseName + ".txd").Replace('\\', '/');
            if (File.Exists(sameNamed)) candidates.Add(sameNamed);

            if (Directory.Exists(dir))
            {
                foreach (var f in Directory.GetFiles(dir, "*.txd"))
                {
                    string norm = f.Replace('\\', '/');
                    if (!candidates.Contains(norm)) candidates.Add(norm);
                }
            }

            foreach (var txdPath in candidates)
            {
                try
                {
                    using var fs = File.OpenRead(txdPath);
                    var dict = TxdParser.Parse(fs);
                    foreach (var kv in dict)
                        combined[kv.Key] = kv.Value;
                    ctx.DependsOnSourceAsset(txdPath);
                }
                catch (System.Exception ex)
                {
                    Debug.LogWarning($"[JspImporter] Failed to parse adjacent TXD '{txdPath}': {ex.Message}");
                }
            }

            return combined;
        }
    }
}
