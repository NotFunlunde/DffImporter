using UnityEditor;
using UnityEngine;
using UnityEngine.Rendering;

namespace BfbbImport.Editor
{
    /// <summary>
    /// One-click scene setup that configures lighting, fog, camera, and materials to match
    /// The SpongeBob SquarePants Movie Game's visual style.
    /// Access via Tools > BfBB DFF > Setup Movie Game Scene Appearance.
    /// </summary>
    public class MovieGameSceneSetup : EditorWindow
    {
        private enum LevelPreset
        {
            Default,
            NoCheeseOfTheDead,
            ShelCityDeadAhead,
            BubbleBlow,
            DriveTowardsTrench,
            WelcomeToTrenchtown,
            CombatArena,
            TurnTheTideMachine
        }

        private bool applyLighting = true;
        private bool applyFog = true;
        private bool applyCamera = true;
        private bool applyShaderToScene = true;
        private LevelPreset preset = LevelPreset.Default;

        // Default values (general Movie Game look)
        private Color ambientColor = new Color(0.45f, 0.5f, 0.6f, 1f);
        private Color sunColor = new Color(1f, 0.94f, 0.84f, 1f);
        private float sunIntensity = 1.1f;
        private Vector3 sunRotation = new Vector3(45f, -40f, 0f);

        private Color fogColor = new Color(0.55f, 0.7f, 0.85f, 1f);
        private float fogStart = 50f;
        private float fogEnd = 150f;

        private float cameraFov = 55f;

        [MenuItem("Tools/BfBB DFF/Setup Movie Game Scene Appearance...")]
        public static void ShowWindow()
        {
            GetWindow<MovieGameSceneSetup>("Movie Game Scene Setup");
        }

        private void OnGUI()
        {
            EditorGUILayout.LabelField("SpongeBob Movie Game Scene Setup", EditorStyles.boldLabel);
            EditorGUILayout.Space();
            EditorGUILayout.HelpBox(
                "Configures the active scene to approximate The SpongeBob SquarePants " +
                "Movie Game's visual style. Select a level preset for environment-specific " +
                "lighting and fog, or use Default for a general look.",
                MessageType.Info);
            EditorGUILayout.Space();

            // Preset selection
            EditorGUI.BeginChangeCheck();
            preset = (LevelPreset)EditorGUILayout.EnumPopup("Level Preset", preset);
            if (EditorGUI.EndChangeCheck())
                ApplyPresetValues();

            EditorGUILayout.Space();

            // Lighting section
            applyLighting = EditorGUILayout.BeginToggleGroup("Lighting", applyLighting);
            EditorGUI.indentLevel++;
            ambientColor = EditorGUILayout.ColorField("Ambient Color", ambientColor);
            sunColor = EditorGUILayout.ColorField("Sun Color", sunColor);
            sunIntensity = EditorGUILayout.FloatField("Sun Intensity", sunIntensity);
            sunRotation = EditorGUILayout.Vector3Field("Sun Rotation", sunRotation);
            EditorGUI.indentLevel--;
            EditorGUILayout.EndToggleGroup();

            EditorGUILayout.Space();

            // Fog section
            applyFog = EditorGUILayout.BeginToggleGroup("Fog", applyFog);
            EditorGUI.indentLevel++;
            fogColor = EditorGUILayout.ColorField("Fog Color", fogColor);
            fogStart = EditorGUILayout.FloatField("Fog Start", fogStart);
            fogEnd = EditorGUILayout.FloatField("Fog End", fogEnd);
            EditorGUI.indentLevel--;
            EditorGUILayout.EndToggleGroup();

            EditorGUILayout.Space();

            // Camera section
            applyCamera = EditorGUILayout.BeginToggleGroup("Camera", applyCamera);
            EditorGUI.indentLevel++;
            cameraFov = EditorGUILayout.Slider("Field of View", cameraFov, 30f, 90f);
            EditorGUI.indentLevel--;
            EditorGUILayout.EndToggleGroup();

            EditorGUILayout.Space();

            // Shader section
            applyShaderToScene = EditorGUILayout.BeginToggleGroup("Apply BfBB Shader to Scene", applyShaderToScene);
            EditorGUI.indentLevel++;
            EditorGUILayout.LabelField("Replaces materials on all renderers with BfBB/Unlit Vertex Color");
            EditorGUI.indentLevel--;
            EditorGUILayout.EndToggleGroup();

            EditorGUILayout.Space();
            EditorGUILayout.Space();

            if (GUILayout.Button("Apply Scene Setup", GUILayout.Height(30)))
            {
                ApplySetup();
            }
        }

        private void ApplyPresetValues()
        {
            switch (preset)
            {
                case LevelPreset.Default:
                    ambientColor = new Color(0.45f, 0.5f, 0.6f, 1f);
                    sunColor = new Color(1f, 0.94f, 0.84f, 1f);
                    sunIntensity = 1.1f;
                    sunRotation = new Vector3(45f, -40f, 0f);
                    fogColor = new Color(0.55f, 0.7f, 0.85f, 1f);
                    fogStart = 50f;
                    fogEnd = 150f;
                    cameraFov = 55f;
                    break;

                case LevelPreset.NoCheeseOfTheDead:
                    // Graveyard/spooky — darker ambient, green-gray fog
                    ambientColor = new Color(0.25f, 0.3f, 0.35f, 1f);
                    sunColor = new Color(0.75f, 0.8f, 0.9f, 1f);
                    sunIntensity = 0.7f;
                    sunRotation = new Vector3(30f, -60f, 0f);
                    fogColor = new Color(0.2f, 0.3f, 0.25f, 1f);
                    fogStart = 30f;
                    fogEnd = 100f;
                    cameraFov = 55f;
                    break;

                case LevelPreset.ShelCityDeadAhead:
                    // Road/desert — warm harsh sun, hazy yellow fog
                    ambientColor = new Color(0.55f, 0.5f, 0.4f, 1f);
                    sunColor = new Color(1f, 0.9f, 0.7f, 1f);
                    sunIntensity = 1.3f;
                    sunRotation = new Vector3(60f, -20f, 0f);
                    fogColor = new Color(0.8f, 0.75f, 0.6f, 1f);
                    fogStart = 60f;
                    fogEnd = 180f;
                    cameraFov = 55f;
                    break;

                case LevelPreset.BubbleBlow:
                    // Underwater — blue-green ambient, aqua fog
                    ambientColor = new Color(0.3f, 0.55f, 0.6f, 1f);
                    sunColor = new Color(0.7f, 0.9f, 1f, 1f);
                    sunIntensity = 0.9f;
                    sunRotation = new Vector3(50f, -30f, 0f);
                    fogColor = new Color(0.2f, 0.5f, 0.6f, 1f);
                    fogStart = 30f;
                    fogEnd = 100f;
                    cameraFov = 55f;
                    break;

                case LevelPreset.DriveTowardsTrench:
                    // Deep sea driving — very dark, deep blue fog
                    ambientColor = new Color(0.15f, 0.2f, 0.35f, 1f);
                    sunColor = new Color(0.5f, 0.6f, 0.8f, 1f);
                    sunIntensity = 0.6f;
                    sunRotation = new Vector3(40f, -45f, 0f);
                    fogColor = new Color(0.05f, 0.1f, 0.25f, 1f);
                    fogStart = 25f;
                    fogEnd = 80f;
                    cameraFov = 60f;
                    break;

                case LevelPreset.WelcomeToTrenchtown:
                    // Trench town — dark purple/blue, neon glow feel
                    ambientColor = new Color(0.2f, 0.15f, 0.3f, 1f);
                    sunColor = new Color(0.6f, 0.5f, 0.8f, 1f);
                    sunIntensity = 0.8f;
                    sunRotation = new Vector3(35f, -50f, 0f);
                    fogColor = new Color(0.1f, 0.08f, 0.2f, 1f);
                    fogStart = 30f;
                    fogEnd = 90f;
                    cameraFov = 55f;
                    break;

                case LevelPreset.CombatArena:
                    // Combat arena — bright, high contrast
                    ambientColor = new Color(0.5f, 0.5f, 0.55f, 1f);
                    sunColor = new Color(1f, 0.95f, 0.9f, 1f);
                    sunIntensity = 1.2f;
                    sunRotation = new Vector3(55f, -30f, 0f);
                    fogColor = new Color(0.6f, 0.65f, 0.75f, 1f);
                    fogStart = 60f;
                    fogEnd = 200f;
                    cameraFov = 58f;
                    break;

                case LevelPreset.TurnTheTideMachine:
                    // Final area — dramatic orange/red sky
                    ambientColor = new Color(0.4f, 0.25f, 0.2f, 1f);
                    sunColor = new Color(1f, 0.7f, 0.4f, 1f);
                    sunIntensity = 1.2f;
                    sunRotation = new Vector3(25f, -60f, 0f);
                    fogColor = new Color(0.6f, 0.35f, 0.2f, 1f);
                    fogStart = 40f;
                    fogEnd = 130f;
                    cameraFov = 55f;
                    break;
            }
        }

        private void ApplySetup()
        {
            Undo.SetCurrentGroupName("Movie Game Scene Setup");
            int undoGroup = Undo.GetCurrentGroup();

            if (applyLighting)
                SetupLighting();
            if (applyFog)
                SetupFog();
            if (applyCamera)
                SetupCamera();
            if (applyShaderToScene)
                ApplyShader();

            Undo.CollapseUndoOperations(undoGroup);

            Debug.Log("[Movie Game Scene Setup] Scene appearance configured.");
            EditorUtility.DisplayDialog("Movie Game Scene Setup",
                "Scene appearance has been configured to match The SpongeBob SquarePants " +
                "Movie Game's visual style.", "OK");
        }

        private void SetupLighting()
        {
            RenderSettings.ambientMode = AmbientMode.Flat;
            RenderSettings.ambientLight = ambientColor;

            Light sun = null;
            var lights = Object.FindObjectsOfType<Light>();
            foreach (var l in lights)
            {
                if (l.type == LightType.Directional)
                {
                    sun = l;
                    break;
                }
            }

            if (sun == null)
            {
                var sunGo = new GameObject("Movie Game Sun");
                Undo.RegisterCreatedObjectUndo(sunGo, "Create Sun");
                sun = sunGo.AddComponent<Light>();
                sun.type = LightType.Directional;
            }
            else
            {
                Undo.RecordObject(sun.transform, "Setup Sun");
                Undo.RecordObject(sun, "Setup Sun");
            }

            sun.color = sunColor;
            sun.intensity = sunIntensity;
            sun.shadows = LightShadows.None;
            sun.transform.eulerAngles = sunRotation;
        }

        private void SetupFog()
        {
            RenderSettings.fog = true;
            RenderSettings.fogMode = FogMode.Linear;
            RenderSettings.fogColor = fogColor;
            RenderSettings.fogStartDistance = fogStart;
            RenderSettings.fogEndDistance = fogEnd;

            if (Camera.main != null)
            {
                Undo.RecordObject(Camera.main, "Setup Fog Background");
                Camera.main.backgroundColor = fogColor;
                Camera.main.clearFlags = CameraClearFlags.SolidColor;
            }
        }

        private void SetupCamera()
        {
            var cam = Camera.main;
            if (cam == null)
            {
                Debug.LogWarning("[Movie Game Scene Setup] No main camera found. Skipping camera setup.");
                return;
            }

            Undo.RecordObject(cam, "Setup Camera");
            cam.fieldOfView = cameraFov;
            cam.farClipPlane = fogEnd + 20f;
        }

        private void ApplyShader()
        {
            var shader = Shader.Find("BfBB/Unlit Vertex Color");
            if (shader == null)
            {
                Debug.LogError("[Movie Game Scene Setup] Could not find 'BfBB/Unlit Vertex Color' shader. " +
                               "Make sure the shader file is in your project.");
                EditorUtility.DisplayDialog("Movie Game Scene Setup",
                    "Could not find 'BfBB/Unlit Vertex Color' shader.\n\n" +
                    "Make sure the DffImporter package (with Runtime/Shaders/BfbbUnlit.shader) " +
                    "is imported into your project.", "OK");
                return;
            }

            int count = 0;
            var renderers = Object.FindObjectsOfType<Renderer>();
            foreach (var renderer in renderers)
            {
                var materials = renderer.sharedMaterials;
                for (int i = 0; i < materials.Length; i++)
                {
                    var mat = materials[i];
                    if (mat == null) continue;
                    if (mat.shader == shader) continue;

                    Undo.RecordObject(mat, "Apply BfBB Shader");

                    Texture mainTex = null;
                    if (mat.HasProperty("_BaseMap"))
                        mainTex = mat.GetTexture("_BaseMap");
                    else if (mat.HasProperty("_MainTex"))
                        mainTex = mat.GetTexture("_MainTex");

                    mat.shader = shader;

                    if (mainTex != null)
                        mat.SetTexture("_MainTex", mainTex);

                    mat.SetFloat("_Cull", 0f);
                    count++;
                }
            }

            Debug.Log($"[Movie Game Scene Setup] Applied BfBB shader to {count} material(s).");
        }
    }
}
