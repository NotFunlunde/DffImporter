using System;
using System.Collections.Generic;
using System.IO;
using UnityEditor;
using UnityEngine;

namespace BfbbImport.Editor
{
    /// <summary>
    /// Imports a Heavy Iron level into the current Unity scene from a .hip + .hop pair.
    ///
    /// The .hop file supplies shared assets (models, textures, JSP level geometry) while
    /// the .hip file supplies level-specific assets and entity placement data.  Either
    /// file may be used alone, but for a complete level import both should be provided.
    ///
    /// Import pipeline:
    ///   1. Parse both archives and merge their asset pools.
    ///   2. Extract all RWTX assets as Texture2D (used for material texturing).
    ///   3. Parse JSP/BSP assets as RenderWare World geometry and build meshes.
    ///   4. Parse MODL assets as RenderWare DFF and build template GameObjects.
    ///   5. Instantiate every entity (SIMP, PLAT, BUTN, PKUP, VIL, NPC, etc.)
    ///      at correct position/rotation/scale with its referenced model and textures.
    ///
    /// Usage: Tools > BfBB DFF > Import HIP HOP Archive...
    /// </summary>
    public class HipImportWindow : EditorWindow
    {
        private string hipFilePath;
        private string hopFilePath;
        private Shader shaderOverride;
        private float importScale = 1f;
        private bool importJsp = true;
        private bool importEntities = true;

        [MenuItem("Tools/BfBB DFF/Import HIP HOP Archive...")]
        private static void Open()
        {
            GetWindow<HipImportWindow>("Import HIP/HOP");
        }

        private void OnGUI()
        {
            EditorGUILayout.LabelField("BfBB HIP/HOP Archive Importer", EditorStyles.boldLabel);
            EditorGUILayout.Space();

            // ── HIP file ──
            EditorGUILayout.BeginHorizontal();
            EditorGUILayout.LabelField("HIP File", GUILayout.Width(70));
            EditorGUILayout.LabelField(string.IsNullOrEmpty(hipFilePath) ? "(none)" : Path.GetFileName(hipFilePath));
            if (GUILayout.Button("Browse...", GUILayout.Width(80)))
            {
                string picked = EditorUtility.OpenFilePanel("Select .hip file", "", "hip");
                if (!string.IsNullOrEmpty(picked)) hipFilePath = picked;
            }
            if (GUILayout.Button("Clear", GUILayout.Width(50)))
                hipFilePath = null;
            EditorGUILayout.EndHorizontal();

            // ── HOP file ──
            EditorGUILayout.BeginHorizontal();
            EditorGUILayout.LabelField("HOP File", GUILayout.Width(70));
            EditorGUILayout.LabelField(string.IsNullOrEmpty(hopFilePath) ? "(none)" : Path.GetFileName(hopFilePath));
            if (GUILayout.Button("Browse...", GUILayout.Width(80)))
            {
                string picked = EditorUtility.OpenFilePanel("Select .hop file", "", "hop");
                if (!string.IsNullOrEmpty(picked)) hopFilePath = picked;
            }
            if (GUILayout.Button("Clear", GUILayout.Width(50)))
                hopFilePath = null;
            EditorGUILayout.EndHorizontal();

            EditorGUILayout.Space();

            // ── Auto-detect companion ──
            if (!string.IsNullOrEmpty(hipFilePath) && string.IsNullOrEmpty(hopFilePath))
            {
                string companion = FindCompanion(hipFilePath, ".hop");
                if (companion != null)
                {
                    EditorGUILayout.HelpBox(
                        $"Found companion: {Path.GetFileName(companion)}",
                        MessageType.Info);
                    if (GUILayout.Button($"Use {Path.GetFileName(companion)}"))
                        hopFilePath = companion;
                }
            }
            else if (!string.IsNullOrEmpty(hopFilePath) && string.IsNullOrEmpty(hipFilePath))
            {
                string companion = FindCompanion(hopFilePath, ".hip");
                if (companion != null)
                {
                    EditorGUILayout.HelpBox(
                        $"Found companion: {Path.GetFileName(companion)}",
                        MessageType.Info);
                    if (GUILayout.Button($"Use {Path.GetFileName(companion)}"))
                        hipFilePath = companion;
                }
            }

            EditorGUILayout.Space();

            shaderOverride = (Shader)EditorGUILayout.ObjectField(
                new GUIContent("Shader Override", "Defaults to URP/Lit → Standard fallback."),
                shaderOverride, typeof(Shader), false);

            importScale = EditorGUILayout.FloatField(
                new GUIContent("Import Scale", "Uniform scale applied to imported objects."),
                importScale);

            importJsp = EditorGUILayout.Toggle(
                new GUIContent("Import JSP Geometry", "Parse and build JSP/BSP level geometry."),
                importJsp);

            importEntities = EditorGUILayout.Toggle(
                new GUIContent("Import Entities", "Instantiate entity placements (SIMP, PLAT, etc.)."),
                importEntities);

            EditorGUILayout.Space();

            bool hasFile = !string.IsNullOrEmpty(hipFilePath) || !string.IsNullOrEmpty(hopFilePath);
            using (new EditorGUI.DisabledScope(!hasFile))
            {
                if (GUILayout.Button("Import Into Scene", GUILayout.Height(30)))
                    DoImport();
            }

            EditorGUILayout.HelpBox(
                "Select a .hip file and/or .hop file. Assets from both are merged:\n" +
                "• RWTX → textures, auto-applied to models and JSP geometry\n" +
                "• MODL → DFF models, instantiated at entity positions\n" +
                "• JSP  → level geometry (RenderWare World/BSP)\n" +
                "• Entities (SIMP, PLAT, etc.) → placed with correct transform\n\n" +
                "The importer auto-detects companion files in the same folder.",
                MessageType.Info);
        }

        // ────────────────────────── Import logic ──────────────────────────

        private void DoImport()
        {
            // Parse both archives and merge assets.
            var allAssets = new List<HipAsset>();
            HipGame game = HipGame.Unknown;
            HipPlatform platform = HipPlatform.Unknown;
            string archiveName = "Level";

            if (!string.IsNullOrEmpty(hopFilePath))
            {
                try
                {
                    var hop = HipHopParser.Parse(hopFilePath);
                    allAssets.AddRange(hop.Assets);
                    if (hop.Game != HipGame.Unknown) game = hop.Game;
                    if (hop.Platform != HipPlatform.Unknown) platform = hop.Platform;
                }
                catch (Exception ex)
                {
                    EditorUtility.DisplayDialog("HIP/HOP Import",
                        $"Failed to parse HOP:\n{ex.Message}", "OK");
                    return;
                }
            }

            if (!string.IsNullOrEmpty(hipFilePath))
            {
                try
                {
                    var hip = HipHopParser.Parse(hipFilePath);
                    allAssets.AddRange(hip.Assets);
                    if (hip.Game != HipGame.Unknown) game = hip.Game;
                    if (hip.Platform != HipPlatform.Unknown) platform = hip.Platform;
                    archiveName = Path.GetFileNameWithoutExtension(hipFilePath);
                }
                catch (Exception ex)
                {
                    EditorUtility.DisplayDialog("HIP/HOP Import",
                        $"Failed to parse HIP:\n{ex.Message}", "OK");
                    return;
                }
            }
            else if (!string.IsNullOrEmpty(hopFilePath))
            {
                archiveName = Path.GetFileNameWithoutExtension(hopFilePath);
            }

            if (platform == HipPlatform.GameCube)
            {
                EditorUtility.DisplayDialog("HIP/HOP Import",
                    "GameCube archives use big-endian asset data which the DFF/TXD parsers don't " +
                    "currently support. Xbox and PS2 archives are fully supported.", "OK");
                return;
            }

            // Build lookup: assetId → HipAsset (later entries override earlier for dedup).
            var assetById = new Dictionary<uint, HipAsset>();
            foreach (var asset in allAssets)
                assetById[asset.AssetId] = asset;

            Shader shader = ResolveShader();
            var sceneRoot = new GameObject(archiveName);
            sceneRoot.transform.localScale = new Vector3(-1f, 1f, 1f); // RW right-hand → Unity left-hand
            Undo.RegisterCreatedObjectUndo(sceneRoot, "Import HIP/HOP");

            // ── Phase 1: Extract textures (RWTX) ──
            EditorUtility.DisplayProgressBar("Importing HIP/HOP", "Extracting textures...", 0.1f);
            var textures = ExtractTextures(allAssets);
            Debug.Log($"[HipImporter] Extracted {textures.Count} texture(s).");

            // ── Phase 2: Build JSP level geometry ──
            int jspCount = 0;
            if (importJsp)
            {
                EditorUtility.DisplayProgressBar("Importing HIP/HOP", "Building JSP geometry...", 0.3f);
                jspCount = BuildJspGeometry(allAssets, textures, shader, sceneRoot.transform);
            }

            // ── Phase 3: Instantiate entities ──
            int entityCount = 0;
            int skippedCount = 0;
            if (importEntities)
            {
                var modelCache = new Dictionary<uint, GameObject>();
                bool bigEndian = platform == HipPlatform.GameCube;

                for (int i = 0; i < allAssets.Count; i++)
                {
                    var asset = allAssets[i];

                    EditorUtility.DisplayProgressBar("Importing HIP/HOP",
                        $"Entities: {asset.Name} ({i + 1}/{allAssets.Count})",
                        0.5f + 0.5f * ((float)i / allAssets.Count));

                    if (!HipEntityReader.IsEntityType(asset.TypeCode))
                        continue;

                    if (asset.Data == null || asset.Data.Length < 48)
                    {
                        skippedCount++;
                        continue;
                    }

                    var placement = HipEntityReader.Read(asset.Data, game, bigEndian);

                    // Find or build the model for this entity.
                    GameObject modelInstance = null;
                    if (placement.ModelAssetId != 0 && assetById.TryGetValue(placement.ModelAssetId, out var modelAsset))
                    {
                        if (!modelCache.TryGetValue(placement.ModelAssetId, out var cachedModel))
                        {
                            cachedModel = BuildModel(modelAsset, textures, shader);
                            modelCache[placement.ModelAssetId] = cachedModel;
                        }

                        if (cachedModel != null)
                            modelInstance = Instantiate(cachedModel);
                    }

                    if (modelInstance == null)
                        modelInstance = new GameObject();

                    modelInstance.name = SanitizeName(asset.Name, asset.TypeCode, asset.AssetId);
                    modelInstance.transform.SetParent(sceneRoot.transform, false);

                    modelInstance.transform.localPosition = new Vector3(
                        placement.PosX * importScale,
                        placement.PosY * importScale,
                        placement.PosZ * importScale);

                    modelInstance.transform.localRotation =
                        Quaternion.Euler(0, placement.Yaw * Mathf.Rad2Deg, 0) *
                        Quaternion.Euler(placement.Pitch * Mathf.Rad2Deg, 0, 0) *
                        Quaternion.Euler(0, 0, placement.Roll * Mathf.Rad2Deg);

                    modelInstance.transform.localScale = Vector3.one;

                    entityCount++;
                }

                // Destroy cached template objects.
                foreach (var kv in modelCache)
                    if (kv.Value != null)
                        DestroyImmediate(kv.Value);
            }

            EditorUtility.ClearProgressBar();

            string msg = $"Imported level '{archiveName}':";
            msg += $"\n• {textures.Count} texture(s)";
            msg += $"\n• {jspCount} JSP sector(s)";
            msg += $"\n• {entityCount} entity/entities placed";
            if (skippedCount > 0)
                msg += $"\n• {skippedCount} entity/entities skipped (data too short)";
            msg += $"\n• Game: {game}, Platform: {platform}";

            Debug.Log($"[HipImporter] {msg}");
            EditorUtility.DisplayDialog("HIP/HOP Import", msg, "OK");
        }

        // ────────────────────────── Texture extraction ──────────────────────────

        private static Dictionary<string, Texture2D> ExtractTextures(List<HipAsset> assets)
        {
            var result = new Dictionary<string, Texture2D>(StringComparer.OrdinalIgnoreCase);

            foreach (var asset in assets)
            {
                if (asset.TypeCode != "RWTX")
                    continue;
                if (asset.Data == null || asset.Data.Length == 0)
                    continue;

                try
                {
                    using var ms = new MemoryStream(asset.Data);
                    var texDict = TxdParser.Parse(ms);
                    foreach (var kv in texDict)
                    {
                        string cleanName = kv.Key;
                        if (cleanName.EndsWith(".RW3", StringComparison.OrdinalIgnoreCase))
                            cleanName = cleanName.Substring(0, cleanName.Length - 4);
                        result[cleanName] = kv.Value;
                    }
                }
                catch (Exception ex)
                {
                    Debug.LogWarning($"[HipImporter] Failed to decode texture '{asset.Name}': {ex.Message}");
                }
            }

            // Also look for standalone .txd-like assets (some archives bundle
            // textures under different type codes or as raw TEXTURE_DICTIONARY blobs).
            foreach (var asset in assets)
            {
                string tc = asset.TypeCode.TrimEnd();
                if (tc == "RWTX") continue; // already processed above
                if (tc != "RAW" && tc != "TEXT") continue;
                if (asset.Data == null || asset.Data.Length < 12) continue;

                // Quick peek: is this a TEXTURE_DICTIONARY or TEXTURE_NATIVE?
                uint firstWord = BitConverter.ToUInt32(asset.Data, 0);
                if (firstWord != RwChunk.TEXTURE_DICTIONARY && firstWord != RwChunk.TEXTURE_NATIVE)
                    continue;

                try
                {
                    using var ms = new MemoryStream(asset.Data);
                    var texDict = TxdParser.Parse(ms);
                    foreach (var kv in texDict)
                    {
                        string cleanName = kv.Key;
                        if (cleanName.EndsWith(".RW3", StringComparison.OrdinalIgnoreCase))
                            cleanName = cleanName.Substring(0, cleanName.Length - 4);
                        if (!result.ContainsKey(cleanName))
                            result[cleanName] = kv.Value;
                    }
                }
                catch { /* not a texture — silently skip */ }
            }

            return result;
        }

        // ────────────────────────── JSP geometry ──────────────────────────

        private static int BuildJspGeometry(List<HipAsset> assets, Dictionary<string, Texture2D> textures,
            Shader shader, Transform parent)
        {
            int totalSectors = 0;

            foreach (var asset in assets)
            {
                // JSP assets use type code "JSP " (with trailing space) or sometimes "BSP ".
                string tc = asset.TypeCode.TrimEnd();
                if (tc != "JSP" && tc != "BSP")
                    continue;
                if (asset.Data == null || asset.Data.Length < 12)
                    continue;

                RwWorld world;
                try
                {
                    using var ms = new MemoryStream(asset.Data);
                    world = JspParser.Parse(ms);
                }
                catch (Exception ex)
                {
                    Debug.LogWarning($"[HipImporter] Failed to parse JSP '{asset.Name}': {ex.Message}");
                    continue;
                }

                if (world.Sectors.Count == 0)
                    continue;

                string jspName = SanitizeName(asset.Name, asset.TypeCode, asset.AssetId);
                var jspRoot = new GameObject(jspName);
                jspRoot.transform.SetParent(parent, false);
                // X flip is on sceneRoot; no per-JSP flip needed.

                for (int i = 0; i < world.Sectors.Count; i++)
                {
                    var sector = world.Sectors[i];
                    var mesh = ClumpBuilder.BuildMesh(sector);
                    mesh.name = $"{jspName}_sector{i}";

                    var materials = ClumpBuilder.BuildMaterials(sector, textures, shader);

                    var sectorGo = new GameObject($"Sector_{i}");
                    sectorGo.transform.SetParent(jspRoot.transform, false);

                    var mf = sectorGo.AddComponent<MeshFilter>();
                    mf.sharedMesh = mesh;
                    var mr = sectorGo.AddComponent<MeshRenderer>();
                    mr.sharedMaterials = materials;

                    totalSectors++;
                }
            }

            return totalSectors;
        }

        // ────────────────────────── Model building ──────────────────────────

        private static GameObject BuildModel(HipAsset modelAsset, Dictionary<string, Texture2D> textures, Shader shader)
        {
            if (modelAsset.Data == null || modelAsset.Data.Length < 12)
                return null;

            try
            {
                using var ms = new MemoryStream(modelAsset.Data);
                var clump = DffParser.Parse(ms);
                string modelName = SanitizeName(modelAsset.Name, "MODL", modelAsset.AssetId);
                var go = ClumpBuilder.Build(clump, modelName, textures, shader);
                // X flip is on sceneRoot; no per-model flip needed.
                return go;
            }
            catch (Exception ex)
            {
                Debug.LogWarning($"[HipImporter] Failed to build model '{modelAsset.Name}': {ex.Message}");
                return null;
            }
        }

        // ────────────────────────── Helpers ──────────────────────────

        private Shader ResolveShader()
        {
            if (shaderOverride != null) return shaderOverride;

            string[] candidates =
            {
                "Universal Render Pipeline/Lit",
                "HDRP/Lit",
                "Standard",
                "Legacy Shaders/Diffuse",
                "Mobile/Diffuse",
                "Sprites/Default",
            };

            foreach (var name in candidates)
            {
                var s = Shader.Find(name);
                if (s != null) return s;
            }

            Debug.LogWarning("[HipImporter] No suitable shader found. Objects will use the default material.");
            return Shader.Find("Standard");
        }

        private static string SanitizeName(string assetName, string typeCode, uint assetId)
        {
            if (!string.IsNullOrEmpty(assetName))
            {
                string clean = assetName;
                if (clean.EndsWith(".dff", StringComparison.OrdinalIgnoreCase) ||
                    clean.EndsWith(".RW3", StringComparison.OrdinalIgnoreCase))
                    clean = clean.Substring(0, clean.Length - 4);
                return clean;
            }
            return $"{typeCode}_{assetId:X8}";
        }

        private static string FindCompanion(string filePath, string extension)
        {
            string dir = Path.GetDirectoryName(filePath);
            string baseName = Path.GetFileNameWithoutExtension(filePath);
            string candidate = Path.Combine(dir, baseName + extension);
            if (File.Exists(candidate)) return candidate;

            // Try case-insensitive match.
            if (Directory.Exists(dir))
            {
                foreach (var f in Directory.GetFiles(dir, "*" + extension))
                {
                    string fn = Path.GetFileNameWithoutExtension(f);
                    if (string.Equals(fn, baseName, StringComparison.OrdinalIgnoreCase))
                        return f;
                }
            }
            return null;
        }
    }
}
