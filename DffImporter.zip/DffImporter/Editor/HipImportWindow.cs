using System;
using System.Collections.Generic;
using System.IO;
using UnityEditor;
using UnityEngine;

namespace BfbbImport.Editor
{
    /// <summary>
    /// Imports a Heavy Iron .hip or .hop archive into the current Unity scene.
    ///
    /// For each entity asset (SIMP, PLAT, BUTN, PKUP, VIL, NPC, etc.) in the archive:
    ///   1. Finds the referenced MODL (model) asset by its asset ID.
    ///   2. Parses the MODL data as a RenderWare .dff and builds a Unity GameObject.
    ///   3. Positions / rotates / scales the object using the entity's placement data.
    ///
    /// Textures (RWTX assets) are extracted from the archive and matched to materials by name,
    /// so models appear textured without needing a separate .txd file.
    ///
    /// Usage: Tools > BfBB DFF > Import HIP/HOP Archive...
    /// </summary>
    public class HipImportWindow : EditorWindow
    {
        private string hipFilePath;
        private Shader shaderOverride;
        private float importScale = 1f;

        [MenuItem("Tools/BfBB DFF/Import HIP HOP Archive...")]
        private static void Open()
        {
            GetWindow<HipImportWindow>("Import HIP/HOP");
        }

        private void OnGUI()
        {
            EditorGUILayout.LabelField("BfBB HIP/HOP Archive Importer", EditorStyles.boldLabel);
            EditorGUILayout.Space();

            EditorGUILayout.BeginHorizontal();
            EditorGUILayout.LabelField("Archive File", GUILayout.Width(100));
            EditorGUILayout.LabelField(string.IsNullOrEmpty(hipFilePath) ? "(none selected)" : Path.GetFileName(hipFilePath));
            if (GUILayout.Button("Browse...", GUILayout.Width(80)))
            {
                string picked = EditorUtility.OpenFilePanel("Select .hip or .hop file", "", "hip,hop");
                if (!string.IsNullOrEmpty(picked)) hipFilePath = picked;
            }
            EditorGUILayout.EndHorizontal();

            shaderOverride = (Shader)EditorGUILayout.ObjectField(
                new GUIContent("Shader Override", "Defaults to URP/Lit → Standard fallback chain if left empty."),
                shaderOverride, typeof(Shader), false);

            importScale = EditorGUILayout.FloatField(
                new GUIContent("Import Scale", "Uniform scale applied to every instantiated object."),
                importScale);

            EditorGUILayout.Space();

            using (new EditorGUI.DisabledScope(string.IsNullOrEmpty(hipFilePath)))
            {
                if (GUILayout.Button("Import Into Scene", GUILayout.Height(30)))
                    DoImport();
            }

            EditorGUILayout.HelpBox(
                "Parses the HIP/HOP archive, extracts models (MODL) and textures (RWTX), " +
                "then instantiates every entity asset (SIMP, PLAT, BUTN, etc.) in the current scene " +
                "with correct position, rotation, and scale.\n\n" +
                "GameCube archives are not yet supported (big-endian asset data). " +
                "Xbox and PS2 archives work out of the box.",
                MessageType.Info);
        }

        // ────────────────────────── Import logic ──────────────────────────

        private void DoImport()
        {
            HipHopFile hip;
            try
            {
                hip = HipHopParser.Parse(hipFilePath);
            }
            catch (Exception ex)
            {
                EditorUtility.DisplayDialog("HIP/HOP Import",
                    $"Failed to parse archive:\n{ex.Message}", "OK");
                return;
            }

            if (hip.Platform == HipPlatform.GameCube)
            {
                EditorUtility.DisplayDialog("HIP/HOP Import",
                    "GameCube archives use big-endian asset data which the DFF/TXD parsers don't " +
                    "currently support. Xbox and PS2 archives are fully supported.", "OK");
                return;
            }

            // Build lookup: assetId → HipAsset
            var assetById = new Dictionary<uint, HipAsset>();
            foreach (var asset in hip.Assets)
                assetById[asset.AssetId] = asset;

            // ── Phase 1: Extract textures (RWTX) ──
            var textures = ExtractTextures(hip.Assets);

            // ── Phase 2: Pre-build models (MODL → DFF → GameObject) ──
            var modelCache = new Dictionary<uint, GameObject>();
            Shader shader = ResolveShader();

            // ── Phase 3: Instantiate entities ──
            string archiveName = Path.GetFileNameWithoutExtension(hipFilePath);
            var sceneRoot = new GameObject(archiveName);
            Undo.RegisterCreatedObjectUndo(sceneRoot, "Import HIP/HOP");

            int entityCount = 0;
            int skippedCount = 0;

            for (int i = 0; i < hip.Assets.Count; i++)
            {
                var asset = hip.Assets[i];

                EditorUtility.DisplayProgressBar("Importing HIP/HOP",
                    $"{asset.Name} ({i + 1}/{hip.Assets.Count})", (float)i / hip.Assets.Count);

                if (!HipEntityReader.IsEntityType(asset.TypeCode))
                    continue;

                if (asset.Data == null || asset.Data.Length < 48)
                {
                    skippedCount++;
                    continue;
                }

                bool bigEndian = hip.Platform == HipPlatform.GameCube;
                var placement = HipEntityReader.Read(asset.Data, hip.Game, bigEndian);

                // Find or build the model for this entity.
                GameObject modelInstance = null;
                if (placement.ModelAssetId != 0 && assetById.TryGetValue(placement.ModelAssetId, out var modelAsset))
                {
                    if (!modelCache.TryGetValue(placement.ModelAssetId, out var cachedModel))
                    {
                        cachedModel = BuildModel(modelAsset, textures, shader);
                        modelCache[placement.ModelAssetId] = cachedModel;
                    }

                    if (cachedModel != null)
                        modelInstance = Instantiate(cachedModel);
                }

                if (modelInstance == null)
                {
                    // No model — create an empty marker so the entity's position is still visible.
                    modelInstance = new GameObject();
                }

                modelInstance.name = SanitizeName(asset.Name, asset.TypeCode, asset.AssetId);
                modelInstance.transform.SetParent(sceneRoot.transform, false);

                modelInstance.transform.localPosition = new Vector3(
                    placement.PosX * importScale,
                    placement.PosY * importScale,
                    placement.PosZ * importScale);

                modelInstance.transform.localRotation =
                    Quaternion.Euler(0, placement.Yaw * Mathf.Rad2Deg, 0) *
                    Quaternion.Euler(placement.Pitch * Mathf.Rad2Deg, 0, 0) *
                    Quaternion.Euler(0, 0, placement.Roll * Mathf.Rad2Deg);

                modelInstance.transform.localScale = new Vector3(
                    placement.ScaleX * importScale,
                    placement.ScaleY * importScale,
                    placement.ScaleZ * importScale);

                entityCount++;
            }

            EditorUtility.ClearProgressBar();

            // Destroy cached template objects (they were just templates for Instantiate).
            foreach (var kv in modelCache)
                if (kv.Value != null)
                    DestroyImmediate(kv.Value);

            string msg = $"Imported {entityCount} entity/entities from {archiveName}.";
            if (skippedCount > 0)
                msg += $"\n{skippedCount} entity/entities skipped (data too short).";
            msg += $"\nTotal assets in archive: {hip.Assets.Count}";
            msg += $"\nGame: {hip.Game}, Platform: {hip.Platform}";

            Debug.Log($"[HipImporter] {msg}");
            EditorUtility.DisplayDialog("HIP/HOP Import", msg, "OK");
        }

        // ────────────────────────── Texture extraction ──────────────────────────

        private static Dictionary<string, Texture2D> ExtractTextures(List<HipAsset> assets)
        {
            var result = new Dictionary<string, Texture2D>(StringComparer.OrdinalIgnoreCase);

            foreach (var asset in assets)
            {
                if (asset.TypeCode != "RWTX")
                    continue;
                if (asset.Data == null || asset.Data.Length == 0)
                    continue;

                try
                {
                    using var ms = new MemoryStream(asset.Data);
                    var texDict = TxdParser.Parse(ms);
                    foreach (var kv in texDict)
                    {
                        // Strip .RW3 suffix if present (BfBB naming convention).
                        string cleanName = kv.Key;
                        if (cleanName.EndsWith(".RW3", StringComparison.OrdinalIgnoreCase))
                            cleanName = cleanName.Substring(0, cleanName.Length - 4);
                        result[cleanName] = kv.Value;
                    }
                }
                catch (Exception ex)
                {
                    // RWTX asset data that fails to parse as TXD is not fatal — the model
                    // will just appear untextured for those materials.
                    Debug.LogWarning($"[HipImporter] Failed to decode texture '{asset.Name}': {ex.Message}");
                }
            }

            return result;
        }

        // ────────────────────────── Model building ──────────────────────────

        private static GameObject BuildModel(HipAsset modelAsset, Dictionary<string, Texture2D> textures, Shader shader)
        {
            if (modelAsset.Data == null || modelAsset.Data.Length < 12)
                return null;

            try
            {
                using var ms = new MemoryStream(modelAsset.Data);
                var clump = DffParser.Parse(ms);
                string modelName = SanitizeName(modelAsset.Name, "MODL", modelAsset.AssetId);
                var go = ClumpBuilder.Build(clump, modelName, textures, shader);
                // Apply the standard RW → Unity mirroring.
                go.transform.localScale = new Vector3(-1f, 1f, 1f);
                return go;
            }
            catch (Exception ex)
            {
                Debug.LogWarning($"[HipImporter] Failed to build model '{modelAsset.Name}': {ex.Message}");
                return null;
            }
        }

        // ────────────────────────── Helpers ──────────────────────────

        private Shader ResolveShader()
        {
            if (shaderOverride != null) return shaderOverride;

            string[] candidates =
            {
                "Universal Render Pipeline/Lit",
                "HDRP/Lit",
                "Standard",
                "Legacy Shaders/Diffuse",
                "Mobile/Diffuse",
                "Sprites/Default",
            };

            foreach (var name in candidates)
            {
                var s = Shader.Find(name);
                if (s != null) return s;
            }

            Debug.LogWarning("[HipImporter] No suitable shader found. Objects will use the default material.");
            return Shader.Find("Standard");
        }

        private static string SanitizeName(string assetName, string typeCode, uint assetId)
        {
            if (!string.IsNullOrEmpty(assetName))
            {
                // Strip file extensions commonly left in asset names.
                string clean = assetName;
                if (clean.EndsWith(".dff", StringComparison.OrdinalIgnoreCase) ||
                    clean.EndsWith(".RW3", StringComparison.OrdinalIgnoreCase))
                    clean = clean.Substring(0, clean.Length - 4);
                return clean;
            }
            return $"{typeCode}_{assetId:X8}";
        }
    }
}
