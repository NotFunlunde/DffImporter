using System.IO;
using UnityEditor;
using UnityEngine;

namespace BfbbImport.Editor
{
    /// <summary>
    /// Imports a .anm (SKB1) animation and builds a Unity AnimationClip driving the bones of an
    /// already-imported .dff model. Bones are matched by traversal order (the same HAnim order
    /// DffParser uses), via whichever SkinnedMeshRenderer is found under the selected root.
    ///
    /// Usage: Tools/BfBB DFF/Import ANM Animation...
    ///   1. Pick a .anm file.
    ///   2. Drag the root of your imported .dff model (the prefab instance in the scene, or the
    ///      asset itself) into the "Target Model" field.
    ///   3. Click Build Clip. A .anim asset is saved next to the .anm file.
    /// </summary>
    public class AnmImportWindow : EditorWindow
    {
        private string animPath;
        private GameObject targetModel;
        private bool reverseBoneOrder;

        [MenuItem("Tools/BfBB DFF/Import ANM Animation...")]
        private static void Open()
        {
            GetWindow<AnmImportWindow>("Import ANM");
        }

        private void OnGUI()
        {
            EditorGUILayout.LabelField("BfBB .anm Animation Importer", EditorStyles.boldLabel);
            EditorGUILayout.Space();

            EditorGUILayout.BeginHorizontal();
            EditorGUILayout.LabelField("ANM File", GUILayout.Width(100));
            EditorGUILayout.LabelField(string.IsNullOrEmpty(animPath) ? "(none selected)" : animPath);
            if (GUILayout.Button("Browse...", GUILayout.Width(80)))
            {
                string picked = EditorUtility.OpenFilePanel("Select .anm file", "", "anm");
                if (!string.IsNullOrEmpty(picked)) animPath = picked;
            }
            EditorGUILayout.EndHorizontal();

            targetModel = (GameObject)EditorGUILayout.ObjectField(
                "Target Model (imported .dff)", targetModel, typeof(GameObject), true);

            reverseBoneOrder = EditorGUILayout.Toggle(
                new GUIContent("Reverse Bone Order", "Matches the same checkbox in BFBBAnimTools.ms — " +
                               "try toggling this if the imported animation looks wrong/scrambled."),
                reverseBoneOrder);

            EditorGUILayout.Space();

            using (new EditorGUI.DisabledScope(string.IsNullOrEmpty(animPath) || targetModel == null))
            {
                if (GUILayout.Button("Build Clip", GUILayout.Height(30)))
                    BuildClip();
            }

            EditorGUILayout.HelpBox(
                "Bones are matched by hierarchy order, not by name — the same convention the " +
                "original 3ds Max tool uses. The target model must have been imported with this " +
                "package's DFF importer (or otherwise have a SkinnedMeshRenderer with a bones array " +
                "in the same order as the source .dff's HAnim bone list).", MessageType.Info);
        }

        private void BuildClip()
        {
            AnmAsset asset;
            try
            {
                using var fs = File.OpenRead(animPath);
                asset = AnmParser.Parse(fs);
            }
            catch (System.Exception ex)
            {
                EditorUtility.DisplayDialog("Import ANM", $"Failed to parse .anm file:\n{ex.Message}", "OK");
                return;
            }

            var smr = targetModel.GetComponentInChildren<SkinnedMeshRenderer>();
            if (smr == null || smr.bones == null || smr.bones.Length == 0)
            {
                EditorUtility.DisplayDialog("Import ANM",
                    "No SkinnedMeshRenderer with bones found under the target model. " +
                    "This animation format only drives skinned bones, not static meshes.", "OK");
                return;
            }

            if (smr.bones.Length != asset.BoneCount)
            {
                bool proceed = EditorUtility.DisplayDialog("Import ANM",
                    $"Bone count mismatch: the .anm expects {asset.BoneCount} bones, but the target " +
                    $"model has {smr.bones.Length}. This usually means the .anm doesn't belong to this " +
                    "model. Continue anyway? Extra/missing bones will just be ignored.",
                    "Continue", "Cancel");
                if (!proceed) return;
            }

            AnimationClip clip = AnmClipBuilder.Build(asset, smr.bones, targetModel.transform, reverseBoneOrder);
            clip.name = Path.GetFileNameWithoutExtension(animPath);

            string defaultDir = "Assets";
            string suggestedPath = $"{defaultDir}/{clip.name}.anim";
            string savePath = EditorUtility.SaveFilePanelInProject(
                "Save Animation Clip", clip.name, "anim", "Choose where to save the imported clip", defaultDir);

            if (string.IsNullOrEmpty(savePath)) return;

            AssetDatabase.CreateAsset(clip, savePath);
            AssetDatabase.SaveAssets();

            Debug.Log($"[AnmImporter] Created animation clip at '{savePath}' " +
                      $"({asset.Keys.Length} keys, {asset.BoneCount} bones, duration {asset.Times[^1]:F2}s).");

            EditorGUIUtility.PingObject(AssetDatabase.LoadAssetAtPath<AnimationClip>(savePath));
        }
    }
}
